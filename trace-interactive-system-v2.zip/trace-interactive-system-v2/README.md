# TRACE / Interactive System Build v2

One page, one system, built around a single subtraction: v1's streamline
particles are gone entirely. What they used to do, read a live
temperature as color, moved into the glass itself instead: the solid is
one piece of colored glass, blue when it's cold out and red when it's
hot, gem-like and richly saturated through its thickest middle, still
genuinely see-through even there. Camera fixed, never moves; drag
rotates the solid itself. See `docs/decisions.md` for the full account:
what broke when the particles came out, what that cost the system's
original thesis, the liquid this build tried and cut twice over before
landing on tinted glass alone, and the WebGPU rewrite this went through
partway in.

Raw WebGPU and hand-written WGSL, no Three.js or other 3D or physics
library. There is no separate liquid anymore: the color comes from
tinting the glass shell's own refraction, depth-graded so it reads
richer through the thick middle and stays clear near the edges, the
same technique a raymarched liquid surface used earlier in this build,
now coloring the one material instead of a second one inside it. Two
earlier liquid approaches (a full GPU particle simulation, then a
raymarched analytic surface) were tried and both removed; see
`docs/decisions.md` for why. This replaces v1's WebGL and GLSL renderer;
that version is kept in the repo as `script.webgl-v2.bak.js`, not
deleted, since WebGPU has real browser-support gaps WebGL does not, a
tradeoff accepted knowingly rather than discovered after the fact. If a
browser has no WebGPU, the page says so in plain text instead of
failing silently.

## Run locally

Serve the folder over HTTP so the background asset and the live weather
fetch both load:

```
python3 -m http.server 8000
```

Then visit `http://localhost:8000`, in a browser with WebGPU support
(recent Chrome, Edge, or Safari).

## Deploy

**Netlify (drag-and-drop):**
1. Go to [app.netlify.com/drop](https://app.netlify.com/drop).
2. Drag this whole folder onto the page.
3. Netlify gives you a live URL. That URL is what you submit.

**Netlify (via GitHub, recommended for staged commits):**
1. Push this repo to GitHub.
2. In Netlify, "Add new site" → "Import an existing project" → pick the repo.
3. No build command and no publish directory override needed: it's a
   static root.

## File structure

```
trace-interactive-system-v2/
├─ index.html                v1 reflection inventory, system panel, canvas, v2 reflection
├─ style.css                 dark, restrained, monospace, unchanged register from v1
├─ script.js                 the WebGPU renderer: tinted-glass raymarch, hand-written WGSL
├─ script.webgl-v2.bak.js    the earlier working WebGL/GLSL version, kept, not deleted
├─ docs/
│  ├─ decisions.md           full decision history, v1 and v2 both, newest at the bottom
│  └─ critique-notes.md      self-assessment against the course's critique lens
├─ process/
│  ├─ screenshots/           v1-01 through v1-04, then v2-01 onward
│  └─ changelog.md           short log of what changed and why, as it happened
└─ assets/
   ├─ concrete-hallway-light.jpg   backdrop in use: licensed Unsplash photo, see docs/decisions.md
   └─ concrete-background.png      earlier backdrop asset, unused, kept rather than deleted
```

## What this version does

- **The one subtraction**: the streamline particles are gone, not
  hidden or dimmed. Cutting them also cut Law 4's deflection rule and,
  with it, v1's whole original thesis about a flow bending around a
  fixed shape. That thesis has no home in this build anymore; the v2
  reflection on the page names this directly rather than glossing over
  it, since the brief calls finding out a cut was load-bearing a real
  result, not a failure.
- **The solid**: the same signed-distance sphere and limbs as v1, shape
  fixed at generation, limb presence still cycling on its own fixed
  clock. Untouched by the subtraction; what changed is that the solid
  now visibly rotates when dragged, since the camera itself no longer
  moves at all. See "Gesture" below.
- **No separate liquid**: an earlier version of this build held a
  simulated liquid, first a full GPU particle simulation, then a direct
  analytic surface, inside a clear shell. Both came back out on direct
  request in favor of one material: the shell itself is tinted colored
  glass, blue to red with the live temperature, thin and barely tinted
  near the silhouette, richer and more saturated through its thickest
  middle, the way real colored glass actually looks. See
  `docs/decisions.md` for the full liquid history this replaced.
- **Material**: v1's glass shading carried over and tuned glossier: a
  broader Fresnel sheen so more of the surface picks up reflection, two
  specular highlights (one tight, one soft) instead of one, and a touch
  of chromatic aberration on the refracted backdrop, adapted from a
  screen-space "liquid glass" CSS library sent as a reference (a
  different, 2D technique, not ported wholesale, but this one piece of
  it translated directly).
- **Gesture**: drag rotates the solid itself, one axis; the camera is
  genuinely fixed and never moves. Full orbit on both axes was tried
  partway through this build, back when a simulated liquid still needed
  tuning, then narrowed back to one axis once that made the physics
  easier to get right; the liquid it was tuned for is gone now, but the
  single axis stayed. What's a full reversal either way: the
  camera-orbits-a-fixed-object rule held since v1's Q06 and Law 1,
  named directly as that rather than folded quietly into old language.
- **Atmosphere**: the same licensed Unsplash photo as v1's backdrop,
  visible directly through any unfilled part of the glass and faintly
  reflected at the shell's edges.
- **Wind**: the same live Open-Meteo reading as v1, now tinting the
  glass directly instead of driving a particle flow. If the fetch fails,
  the readout says `offline` instead of showing a number that isn't
  real, same as always.
- **Fullscreen**: unchanged from v1, a viewing option, not part of the
  gesture language.

See `docs/decisions.md` for the complete history, v1 and v2 both.
