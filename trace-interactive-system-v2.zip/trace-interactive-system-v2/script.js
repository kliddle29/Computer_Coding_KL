// TRACE / Interactive System Build v2 -- WebGPU
// There is no separate liquid. This build tried one twice, a full GPU
// particle simulation, then a direct analytic surface, and cut both on
// direct request for never looking as clear and crisp as the reference
// photos of real colored glass. What is here instead is one material:
// the raymarched glass shell itself, tinted blue to red by the live
// temperature, depth-graded by a thickness march through the shell so
// it reads clear near the silhouette and richly saturated through the
// thick middle. See docs/decisions.md for the full history.
//
// The camera never moves. Dragging rotates the solid (shell + limbs)
// in front of it, one axis, evaluated by transforming the raymarched
// point into the shell's own rotating frame before its SDF runs.

(function () {
  'use strict';

  var canvas = document.getElementById('stage');

  if (!('gpu' in navigator)) {
    canvas.parentNode.insertBefore(
      document.createTextNode('WebGPU is not available in this browser.'),
      canvas
    );
    return;
  }

  function normalize3(v) {
    var l = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z) || 1;
    return { x: v.x / l, y: v.y / l, z: v.z / l };
  }
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

  var JITTER_RATIO = 0.15;
  var BASE_RADIUS = 60 * (1 + (Math.random() * 2 - 1) * JITTER_RATIO);
  var LIMB_COUNT = 9;
  var limbDirs = [], limbHeights = [], limbPhases = [], limbSpeeds = [];
  (function generateLimbs() {
    for (var i = 0; i < LIMB_COUNT; i++) {
      var d = normalize3({ x: Math.random() * 2 - 1, y: Math.random() * 2 - 1, z: Math.random() * 2 - 1 });
      limbDirs.push(d.x, d.y, d.z);
      limbHeights.push(0.35 + Math.random() * 0.55);
      limbPhases.push(Math.random());
      limbSpeeds.push(0.05 + Math.random() * 0.04);
    }
  })();

  var LIGHT = normalize3({ x: 0.35, y: 0.9, z: 0.5 });

  var windOut = document.getElementById('wind-temp-out');
  var WIND = { tempF: null, temp01: 0.5 };
  function setWind(t) {
    WIND.tempF = t;
    WIND.temp01 = clamp((t - 40) / 80, 0, 1);
    if (windOut) windOut.textContent = Math.round(t) + '°F';
  }
  fetch('https://api.open-meteo.com/v1/forecast?latitude=33.4484&longitude=-112.0740&current=temperature_2m&temperature_unit=fahrenheit')
    .then(function (r) { return r.json(); })
    .then(function (data) {
      if (data && data.current && typeof data.current.temperature_2m === 'number') {
        setWind(data.current.temperature_2m);
      } else {
        throw new Error('unexpected response shape');
      }
    })
    .catch(function () {
      if (windOut) windOut.textContent = 'offline';
    });

  canvas.setAttribute('role', 'img');
  canvas.setAttribute('aria-label',
    'TRACE. A solid piece of colored glass, red for warm, blue for cool, richest through ' +
    'its thick middle and clear near its edge. Drag left or right to rotate the solid; ' +
    'the camera itself never moves. Not adjustable by keyboard.');

  var yaw = 0.6, pitch = -0.2;
  var dragging = false, lastX = null;

  function toLocalXY(e) {
    var rect = canvas.getBoundingClientRect();
    var ev = e.touches ? e.touches[0] : e;
    return {
      x: (ev.clientX - rect.left) * (canvas.width / rect.width),
      y: (ev.clientY - rect.top) * (canvas.height / rect.height)
    };
  }
  // Yaw only, on request: simpler to get sloshing right, and closer
  // again to the single-axis discipline this project held through most
  // of v1.
  function pressStart(e) { var p = toLocalXY(e); dragging = true; lastX = p.x; }
  function pressMove(e) {
    if (!dragging) return;
    var p = toLocalXY(e);
    yaw += (p.x - lastX) * 0.01;
    lastX = p.x;
  }
  function pressEnd() { dragging = false; lastX = null; }
  canvas.addEventListener('mousedown', pressStart);
  window.addEventListener('mousemove', pressMove);
  window.addEventListener('mouseup', pressEnd);
  canvas.addEventListener('touchstart', pressStart, { passive: true });
  canvas.addEventListener('touchmove', pressMove, { passive: true });
  window.addEventListener('touchend', pressEnd);

  var stageEl = document.querySelector('.stage');
  var fsBtn = document.getElementById('fullscreen-toggle');
  var fsRequest = stageEl.requestFullscreen || stageEl.webkitRequestFullscreen;
  var fsExit = document.exitFullscreen || document.webkitExitFullscreen;
  function fsElement() { return document.fullscreenElement || document.webkitFullscreenElement || null; }
  if (fsBtn) {
    if (!fsRequest) {
      fsBtn.style.display = 'none';
    } else {
      fsBtn.addEventListener('click', function () {
        if (fsElement()) fsExit.call(document); else fsRequest.call(stageEl);
      });
      var updateFsLabel = function () { fsBtn.textContent = fsElement() ? 'exit fullscreen' : 'fullscreen'; };
      document.addEventListener('fullscreenchange', function () { updateFsLabel(); resize(); });
      document.addEventListener('webkitfullscreenchange', function () { updateFsLabel(); resize(); });
      updateFsLabel();
    }
  }

  var ratio = 900 / 600;
  function resize() {
    var cssWidth;
    if (fsElement()) {
      cssWidth = Math.min(window.innerWidth, window.innerHeight * ratio);
      canvas.style.width = cssWidth + 'px';
      canvas.style.height = (cssWidth / ratio) + 'px';
    } else {
      cssWidth = canvas.clientWidth || 900;
      canvas.style.width = '';
      canvas.style.height = '';
    }
    canvas.width = Math.round(cssWidth);
    canvas.height = Math.round(cssWidth / ratio);
  }
  resize();
  var resizeTimer = null;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(resize, 120);
  });

  var CLOCK = 0;

  var SDF_WGSL = [
    'fn sdSphereF(p: vec3f, r: f32) -> f32 { return length(p) - r; }',
    'fn sdCapsuleF(p: vec3f, a: vec3f, b: vec3f, ra: f32, rb: f32) -> f32 {',
    '  let pa = p - a; let ba = b - a;',
    '  let h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);',
    '  return length(pa - ba * h) - mix(ra, rb, h);',
    '}',
    'fn sminF(a: f32, b: f32, k: f32) -> f32 {',
    '  let h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);',
    '  return mix(b, a, h) - k * h * (1.0 - h);',
    '}',
    'fn limbPresenceF(phase: f32, speed: f32, t: f32) -> f32 {',
    '  let c = fract(t * speed + phase);',
    '  return smoothstep(0.0, 0.16, c) - smoothstep(0.55, 0.72, c);',
    '}',
    'fn mapSceneF(p: vec3f, baseR: f32, t: f32, limbDir: array<vec4f,9>, limbParam: array<vec4f,9>) -> f32 {',
    '  var d = sdSphereF(p, baseR);',
    '  for (var i = 0u; i < 9u; i = i + 1u) {',
    '    let ph = limbParam[i].x; let sp = limbParam[i].y; let ht = limbParam[i].z;',
    '    let presence = limbPresenceF(ph, sp, t);',
    '    if (presence < 0.003) { continue; }',
    '    let dir = normalize(limbDir[i].xyz);',
    '    let len = baseR * (0.6 + ht) * presence;',
    '    let cap = sdCapsuleF(p, vec3f(0.0), dir * len, baseR * 0.5, baseR * 0.12);',
    '    d = sminF(d, cap, baseR * 0.4);',
    '  }',
    '  return d;',
    '}',
    // The shell rotates in front of a fixed camera: transform the fixed-
    // frame point into the shell's own local frame before evaluating it.
    'fn rotYP_inv(p: vec3f, yaw: f32, pitch: f32) -> vec3f {',
    '  let cp = cos(pitch); let sp = sin(pitch);',
    '  let y1 = p.y * cp + p.z * sp;',
    '  let z1 = -p.y * sp + p.z * cp;',
    '  let cy = cos(yaw); let sy = sin(yaw);',
    '  let x = p.x * cy - z1 * sy;',
    '  let z = p.x * sy + z1 * cy;',
    '  return vec3f(x, y1, z);',
    '}',
    'fn mapSceneFixed(pFixed: vec3f, yaw: f32, pitch: f32, baseR: f32, t: f32, ld: array<vec4f,9>, lp: array<vec4f,9>) -> f32 {',
    '  return mapSceneF(rotYP_inv(pFixed, yaw, pitch), baseR, t, ld, lp);',
    '}'
  ].join('\n');

  var BACKDROP_WGSL = [
    '@vertex fn vs(@builtin(vertex_index) vi: u32) -> @builtin(position) vec4f {',
    '  var pos = array<vec2f, 4>(vec2f(-1,-1), vec2f(1,-1), vec2f(-1,1), vec2f(1,1));',
    '  return vec4f(pos[vi], 0.0, 1.0);',
    '}',
    '@group(0) @binding(0) var bgSamp: sampler;',
    '@group(0) @binding(1) var bgTex: texture_2d<f32>;',
    '@group(0) @binding(2) var<uniform> res: vec2f;',
    '@fragment fn fs(@builtin(position) fc: vec4f) -> @location(0) vec4f {',
    '  let uv = vec2f(fc.x / res.x, 1.0 - fc.y / res.y);',
    '  let c = textureSample(bgTex, bgSamp, uv).rgb * 0.55;',
    '  return vec4f(c, 1.0);',
    '}'
  ].join('\n');

  var GLASS_WGSL = [
    'struct U2 {',
    '  resX: f32, resY: f32, yaw: f32, pitch: f32,',
    '  camDist: f32, focal: f32, baseRadius: f32, time: f32,',
    '  lightX: f32, lightY: f32, lightZ: f32, bgR: f32, bgG: f32, bgB: f32, temp01: f32, _pad0: f32,',
    '  _pad1: f32, _pad2: f32, _pad3: f32, _pad4: f32,',
    '  limbDir: array<vec4f, 9>,',
    '  limbParam: array<vec4f, 9>,',
    '};',
    '@group(0) @binding(0) var<uniform> U: U2;',
    '@group(0) @binding(1) var sceneSamp: sampler;',
    '@group(0) @binding(2) var sceneTex: texture_2d<f32>;',
    SDF_WGSL,
    'fn calcNormalF(p: vec3f, yaw: f32, pitch: f32) -> vec3f {',
    '  let e = 0.05;',
    '  let dx = mapSceneFixed(p+vec3f(e,0.0,0.0), yaw, pitch, U.baseRadius, U.time, U.limbDir, U.limbParam) - mapSceneFixed(p-vec3f(e,0.0,0.0), yaw, pitch, U.baseRadius, U.time, U.limbDir, U.limbParam);',
    '  let dy = mapSceneFixed(p+vec3f(0.0,e,0.0), yaw, pitch, U.baseRadius, U.time, U.limbDir, U.limbParam) - mapSceneFixed(p-vec3f(0.0,e,0.0), yaw, pitch, U.baseRadius, U.time, U.limbDir, U.limbParam);',
    '  let dz = mapSceneFixed(p+vec3f(0.0,0.0,e), yaw, pitch, U.baseRadius, U.time, U.limbDir, U.limbParam) - mapSceneFixed(p-vec3f(0.0,0.0,e), yaw, pitch, U.baseRadius, U.time, U.limbDir, U.limbParam);',
    '  return normalize(vec3f(dx, dy, dz));',
    '}',
    '@vertex fn vs(@builtin(vertex_index) vi: u32) -> @builtin(position) vec4f {',
    '  var pos = array<vec2f, 4>(vec2f(-1,-1), vec2f(1,-1), vec2f(-1,1), vec2f(1,1));',
    '  return vec4f(pos[vi], 0.0, 1.0);',
    '}',
    '@fragment fn fs(@builtin(position) fc: vec4f) -> @location(0) vec4f {',
    '  let res = vec2f(U.resX, U.resY);',
    '  let px = fc.xy - 0.5 * res;',
    '  let roP = vec3f(0.0, 0.0, -U.camDist);',
    '  let rd = normalize(vec3f(px.x/U.focal, -px.y/U.focal, 1.0));',
    '  let boundR = U.baseRadius * 2.8;',
    '  let b = dot(roP, rd);',
    '  let cDisc = b*b - (dot(roP,roP) - boundR*boundR);',
    '  if (cDisc < 0.0) { discard; }',
    '  var t = max(0.0, -b - sqrt(cDisc));',
    '  let tMax = -b + sqrt(cDisc);',
    '  var hit = false;',
    '  var p = roP;',
    '  for (var i = 0; i < 64; i = i + 1) {',
    '    p = roP + rd * t;',
    '    let d = mapSceneFixed(p, U.yaw, U.pitch, U.baseRadius, U.time, U.limbDir, U.limbParam);',
    '    if (d < 0.0015) { hit = true; break; }',
    '    t = t + d;',
    '    if (t > tMax) { break; }',
    '  }',
    '  if (!hit) { discard; }',
    '  let n = calcNormalF(p, U.yaw, U.pitch);',
    '  let viewDir = normalize(roP - p);',
    // A lower exponent than before: more of the surface picks up some
    // reflection, a broad glassy sheen like a polished gem, not only a
    // thin rim right at the silhouette edge.
    '  let fresnel = mix(0.035, 1.0, pow(1.0 - clamp(dot(n, viewDir), 0.0, 1.0), 2.3));',
    '  let reflDir = reflect(-viewDir, n);',
    '  let sky = mix(vec3f(0.06,0.07,0.09), vec3f(0.95,0.97,1.0), smoothstep(-0.7, 0.85, reflDir.y));',
    '  let refrDir = refract(-viewDir, n, 1.0/1.45);',

    // No separate liquid: the glass itself is tinted colored glass, the
    // temperature reading setting the tint, not a second material inside
    // a clear shell. Thickness (a second march from the entry point to
    // where the ray exits the shell) is what gives it the gem-like
    // depth real colored glass has: thin near the silhouette, where it
    // barely tints the room behind it, richer and more saturated through
    // the thick middle of the sphere.
    '  var p2 = p + refrDir * (U.baseRadius*0.02);',
    '  var thickness = 0.0;',
    '  for (var j = 0; j < 40; j = j + 1) {',
    '    let dGlass = mapSceneFixed(p2, U.yaw, U.pitch, U.baseRadius, U.time, U.limbDir, U.limbParam);',
    '    if (dGlass > U.baseRadius*0.01) { break; }',
    '    let step = max(-dGlass, U.baseRadius*0.03);',
    '    p2 = p2 + refrDir * step;',
    '    thickness = thickness + step;',
    '  }',
    '  let depthT = clamp(thickness / (U.baseRadius*1.7), 0.0, 1.0);',

    // textureSample must run in uniform control flow: sampled here
    // unconditionally, not inside a branch.
    '  let bgUv = fc.xy / res + refrDir.xy * 0.03;',
    // Chromatic aberration: real glass bends red and blue light by
    // slightly different amounts, so the refracted image separates a
    // little at its edges instead of staying perfectly neutral.
    '  let chroma = refrDir.xy * 0.006;',
    '  let bgR = textureSample(sceneTex, sceneSamp, clamp(bgUv - chroma, vec2f(0.0), vec2f(1.0))).r;',
    '  let bgG = textureSample(sceneTex, sceneSamp, clamp(bgUv, vec2f(0.0), vec2f(1.0))).g;',
    '  let bgB = textureSample(sceneTex, sceneSamp, clamp(bgUv + chroma, vec2f(0.0), vec2f(1.0))).b;',
    '  let bgSample = vec3f(bgR, bgG, bgB);',
    '  let cold = vec3f(0.2, 0.5, 0.99);',
    '  let hot = vec3f(0.99, 0.18, 0.08);',
    '  let tintCol = mix(cold, hot, U.temp01);',
    // A little of the room still shows through even at the thickest
    // point (genuinely see-through, not a solid paint), but the tint
    // dominates and deepens with thickness, the way real colored glass
    // gets richer, not paler, the more of it light has to pass through.
    '  let shallow = mix(bgSample, tintCol, 0.55);',
    '  let deep = tintCol * (0.55 + 0.5*bgSample.r) + tintCol * 0.3;',
    '  let behind = mix(shallow, deep, depthT);',

    '  var col = mix(behind, sky, fresnel);',
    '  let lightDir = normalize(vec3f(U.lightX, U.lightY, U.lightZ));',
    '  let h = normalize(lightDir + viewDir);',
    // Two highlights, not one: a tight hard glint plus a broader, softer
    // bloom around it, the way a real polished glass surface catches a
    // light source as more than a single pinpoint.
    '  let spec = pow(max(dot(n, h), 0.0), 220.0);',
    '  let specBroad = pow(max(dot(n, h), 0.0), 24.0);',
    '  col = col + vec3f(spec) * 1.6 + vec3f(specBroad) * 0.35;',
    '  let fogT = clamp((length(p - roP) - U.camDist*0.5) / (U.camDist*1.8), 0.0, 1.0);',
    '  col = mix(col, vec3f(U.bgR, U.bgG, U.bgB), fogT * 0.12);',
    '  return vec4f(col, 1.0);',
    '}'
  ].join('\n');

  var BG = [10 / 255, 10 / 255, 10 / 255];

  async function main() {
    var adapter = await navigator.gpu.requestAdapter();
    if (!adapter) { showFallback(); return; }
    var device = await adapter.requestDevice();
    device.lost.then(function () { /* not recovered; a reload picks up a fresh device */ });

    var context = canvas.getContext('webgpu');
    var format = navigator.gpu.getPreferredCanvasFormat();
    context.configure({ device: device, format: format, alphaMode: 'opaque' });

    var sceneTex = null, sceneView = null;
    function allocScene(w, h) {
      if (sceneTex) sceneTex.destroy();
      sceneTex = device.createTexture({
        size: [w, h], format: format,
        usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING
      });
      sceneView = sceneTex.createView();
    }
    allocScene(canvas.width, canvas.height);

    var sampler = device.createSampler({ magFilter: 'linear', minFilter: 'linear' });

    var bgImg = new Image();
    var bgTexGPU = device.createTexture({
      size: [1, 1], format: 'rgba8unorm',
      usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST
    });
    device.queue.writeTexture({ texture: bgTexGPU }, new Uint8Array([10, 10, 10, 255]), { bytesPerRow: 4 }, [1, 1]);
    bgImg.onload = function () {
      createImageBitmap(bgImg).then(function (bitmap) {
        bgTexGPU = device.createTexture({
          size: [bitmap.width, bitmap.height], format: 'rgba8unorm',
          usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST | GPUTextureUsage.RENDER_ATTACHMENT
        });
        device.queue.copyExternalImageToTexture({ source: bitmap }, { texture: bgTexGPU }, [bitmap.width, bitmap.height]);
        rebuildBackdropBindGroup();
      });
    };
    bgImg.src = 'assets/concrete-hallway-light.jpg';

    var bgResBuf = device.createBuffer({ size: 8, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
    var bgModule = device.createShaderModule({ code: BACKDROP_WGSL });
    var bgPipeline = device.createRenderPipeline({
      layout: 'auto',
      vertex: { module: bgModule, entryPoint: 'vs' },
      fragment: { module: bgModule, entryPoint: 'fs', targets: [{ format: format }] },
      primitive: { topology: 'triangle-strip' }
    });
    var bgBindGroup = null;
    function rebuildBackdropBindGroup() {
      bgBindGroup = device.createBindGroup({
        layout: bgPipeline.getBindGroupLayout(0),
        entries: [
          { binding: 0, resource: sampler },
          { binding: 1, resource: bgTexGPU.createView() },
          { binding: 2, resource: { buffer: bgResBuf } }
        ]
      });
    }
    rebuildBackdropBindGroup();

    var glassUniformBuf = device.createBuffer({
      size: 20 * 4 + 9 * 16 + 9 * 16,
      usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
    });
    var glassModule = device.createShaderModule({ code: GLASS_WGSL });
    var glassPipeline = device.createRenderPipeline({
      layout: 'auto',
      vertex: { module: glassModule, entryPoint: 'vs' },
      fragment: { module: glassModule, entryPoint: 'fs', targets: [{ format: format }] },
      primitive: { topology: 'triangle-strip' }
    });
    var glassBindGroup = null;
    function rebuildGlassBindGroup() {
      glassBindGroup = device.createBindGroup({
        layout: glassPipeline.getBindGroupLayout(0),
        entries: [
          { binding: 0, resource: { buffer: glassUniformBuf } },
          { binding: 1, resource: sampler },
          { binding: 2, resource: sceneView }
        ]
      });
    }
    rebuildGlassBindGroup();

    function showFallback() {
      canvas.parentNode.insertBefore(
        document.createTextNode('WebGPU is not available in this browser.'),
        canvas
      );
      canvas.style.display = 'none';
    }

    var limbDirF32 = new Float32Array(9 * 4);
    var limbParamF32 = new Float32Array(9 * 4);
    for (var li = 0; li < 9; li++) {
      limbDirF32[li * 4 + 0] = limbDirs[li * 3 + 0];
      limbDirF32[li * 4 + 1] = limbDirs[li * 3 + 1];
      limbDirF32[li * 4 + 2] = limbDirs[li * 3 + 2];
      limbParamF32[li * 4 + 0] = limbPhases[li];
      limbParamF32[li * 4 + 1] = limbSpeeds[li];
      limbParamF32[li * 4 + 2] = limbHeights[li];
    }

    var lastResizeW = -1, lastResizeH = -1;

    function frame() {
      if (canvas.width !== lastResizeW || canvas.height !== lastResizeH) {
        allocScene(canvas.width, canvas.height);
        rebuildGlassBindGroup();
        lastResizeW = canvas.width; lastResizeH = canvas.height;
      }

      CLOCK += 1 / 60;

      device.queue.writeBuffer(bgResBuf, 0, new Float32Array([canvas.width, canvas.height]));

      var gu = new Float32Array(20 + 9 * 4 + 9 * 4);
      gu[0] = canvas.width; gu[1] = canvas.height; gu[2] = yaw; gu[3] = pitch;
      gu[4] = 340; gu[5] = canvas.width * 0.9; gu[6] = BASE_RADIUS; gu[7] = CLOCK;
      gu[8] = LIGHT.x; gu[9] = LIGHT.y; gu[10] = LIGHT.z;
      gu[11] = BG[0]; gu[12] = BG[1]; gu[13] = BG[2]; gu[14] = WIND.temp01;
      gu.set(limbDirF32, 20);
      gu.set(limbParamF32, 20 + 36);
      device.queue.writeBuffer(glassUniformBuf, 0, gu);

      var encoder = device.createCommandEncoder();

      var scenePass = encoder.beginRenderPass({
        colorAttachments: [{ view: sceneView, clearValue: { r: BG[0], g: BG[1], b: BG[2], a: 1 }, loadOp: 'clear', storeOp: 'store' }]
      });
      scenePass.setPipeline(bgPipeline);
      scenePass.setBindGroup(0, bgBindGroup);
      scenePass.draw(4);
      scenePass.end();

      var screenView = context.getCurrentTexture().createView();
      var finalPass = encoder.beginRenderPass({
        colorAttachments: [{ view: screenView, clearValue: { r: BG[0], g: BG[1], b: BG[2], a: 1 }, loadOp: 'clear', storeOp: 'store' }]
      });
      finalPass.setPipeline(bgPipeline);
      finalPass.setBindGroup(0, bgBindGroup);
      finalPass.draw(4);
      finalPass.setPipeline(glassPipeline);
      finalPass.setBindGroup(0, glassBindGroup);
      finalPass.draw(4);
      finalPass.end();

      device.queue.submit([encoder.finish()]);
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  main().catch(function (err) {
    console.error('WebGPU init failed:', err);
    canvas.parentNode.insertBefore(
      document.createTextNode('WebGPU failed to initialize in this browser: ' + err.message),
      canvas
    );
  });

})();
