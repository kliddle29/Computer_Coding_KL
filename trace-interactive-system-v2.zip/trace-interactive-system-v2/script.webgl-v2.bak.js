// TRACE / Interactive System Build v2
// v2's one subtraction: the streamline particles are gone entirely, not
// hidden or dimmed. What they did (show a live temperature as color, show
// motion) now happens inside the glass itself instead of floating outside
// it: the solid is a clear glass shell with colored liquid inside, red for
// hot, blue for cold, that stirs when you drag. No new input was added to
// get this; it reuses the same temperature reading and the same drag
// gesture the system already had. See docs/decisions.md for the full case,
// including what broke when the particles came out and had to be rebuilt
// into something else.

(function () {
  'use strict';

  var canvas = document.getElementById('stage');
  var gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
  if (!gl) {
    canvas.parentNode.insertBefore(
      document.createTextNode('WebGL is not available in this browser.'),
      canvas
    );
    return;
  }

  // ---------- shared math ----------

  function normalize(v) {
    var l = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z) || 1;
    return { x: v.x / l, y: v.y / l, z: v.z / l };
  }
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

  // ---------- Law 1: the solid's parameters, chosen once, at generation ----------
  // Unchanged from v1: a signed-distance field, a sphere with a handful of
  // limb bumps smooth-blended in. Random choices happen once, here, and
  // nothing about the solid's shape changes after this point. Limb
  // *presence* still cycles on a fixed clock (below, in the shader), the
  // same named departure from Law 1's literal text that v1 already
  // documented; v2 did not touch this, on direct request to keep it.

  var JITTER_RATIO = 0.15;
  var BASE_RADIUS = 60 * (1 + (Math.random() * 2 - 1) * JITTER_RATIO);
  var LIMB_COUNT = 9;
  var limbDirs = [];
  var limbHeights = [];
  var limbPhases = [];
  var limbSpeeds = [];
  (function generateLimbs() {
    for (var i = 0; i < LIMB_COUNT; i++) {
      var d = normalize({ x: Math.random() * 2 - 1, y: Math.random() * 2 - 1, z: Math.random() * 2 - 1 });
      limbDirs.push(d.x, d.y, d.z);
      limbHeights.push(0.35 + Math.random() * 0.55);
      limbPhases.push(Math.random());
      limbSpeeds.push(0.05 + Math.random() * 0.04);
    }
  })();

  var LIGHT = normalize({ x: 0.35, y: 0.9, z: 0.5 });

  // ---------- wind: now colors the liquid instead of driving particle speed ----------
  // The fetch itself is unchanged from v1: a live reading or nothing, never
  // a guess presented as real. What changed is what the number feeds. The
  // readout under the canvas still shows the real number or "offline"; the
  // shader gets a separate 0..1 value for color, defaulting to a neutral
  // 0.5 (an even mix of the two colors, not a claim of either) until a
  // real reading lands.

  var windOut = document.getElementById('wind-temp-out');
  var WIND = { tempF: null, temp01: 0.5 };
  function setWind(t) {
    WIND.tempF = t;
    WIND.temp01 = clamp((t - 40) / 80, 0, 1);
    if (windOut) windOut.textContent = Math.round(t) + '°F';
  }
  fetch('https://api.open-meteo.com/v1/forecast?latitude=33.4484&longitude=-112.0740&current=temperature_2m&temperature_unit=fahrenheit')
    .then(function (r) { return r.json(); })
    .then(function (data) {
      if (data && data.current && typeof data.current.temperature_2m === 'number') {
        setWind(data.current.temperature_2m);
      } else {
        throw new Error('unexpected response shape');
      }
    })
    .catch(function () {
      if (windOut) windOut.textContent = 'offline';
    });

  var CLOCK = 0;

  // ---------- gesture: drag → yaw, the only input this system takes ----------
  // Unchanged from v1. What's new: the same drag also feeds a "kick" into
  // the liquid below, so dragging visibly stirs it. That is not a second
  // gesture, it's the existing one doing more with the same input.

  canvas.setAttribute('role', 'img');
  canvas.setAttribute('aria-label',
    'TRACE. A clear glass solid with colored liquid inside, red for warm, blue ' +
    'for cool, that sloshes when dragged. Drag in any direction to orbit the camera; ' +
    'not adjustable by keyboard.');

  var yaw = 0.6, pitch = -0.2;
  var dragging = false, lastX = null;
  var flowKick = 0; // reacts to actual drag speed, not just whether a drag is happening
  var prevYaw = yaw;
  // Sloshing: a damped spring on the liquid surface's tilt, kicked by how
  // fast yaw is changing right now. The object itself never moves, per
  // Law 1; only the camera orbits. This is a named, deliberate design
  // choice, not a physics claim: it treats a fast drag as if it jostled
  // what's inside, so the liquid can visibly climb one side of the glass
  // instead of just sitting as a flat, level line. See docs/decisions.md.
  var tiltX = 0, tiltZ = 0, tiltVelX = 0, tiltVelZ = 0;
  var lastY = null;
  function toLocalXY(e) {
    var rect = canvas.getBoundingClientRect();
    var ev = e.touches ? e.touches[0] : e;
    return {
      x: (ev.clientX - rect.left) * (canvas.width / rect.width),
      y: (ev.clientY - rect.top) * (canvas.height / rect.height)
    };
  }
  function pressStart(e) { var p = toLocalXY(e); dragging = true; lastX = p.x; lastY = p.y; }
  function pressMove(e) {
    if (!dragging) return;
    var p = toLocalXY(e);
    yaw += (p.x - lastX) * 0.01;
    pitch = clamp(pitch + (p.y - lastY) * 0.01, -1.3, 1.3);
    lastX = p.x; lastY = p.y;
  }
  function pressEnd() { dragging = false; lastX = null; lastY = null; }
  canvas.addEventListener('mousedown', pressStart);
  window.addEventListener('mousemove', pressMove);
  window.addEventListener('mouseup', pressEnd);
  canvas.addEventListener('touchstart', pressStart, { passive: true });
  canvas.addEventListener('touchmove', pressMove, { passive: true });
  window.addEventListener('touchend', pressEnd);

  // ---------- fullscreen toggle (a viewing utility, not part of the gesture language) ----------

  var stageEl = document.querySelector('.stage');
  var fsBtn = document.getElementById('fullscreen-toggle');
  var fsRequest = stageEl.requestFullscreen || stageEl.webkitRequestFullscreen;
  var fsExit = document.exitFullscreen || document.webkitExitFullscreen;
  function fsElement() { return document.fullscreenElement || document.webkitFullscreenElement || null; }
  if (fsBtn) {
    if (!fsRequest) {
      fsBtn.style.display = 'none';
    } else {
      fsBtn.addEventListener('click', function () {
        if (fsElement()) fsExit.call(document); else fsRequest.call(stageEl);
      });
      var updateFsLabel = function () { fsBtn.textContent = fsElement() ? 'exit fullscreen' : 'fullscreen'; };
      document.addEventListener('fullscreenchange', function () { updateFsLabel(); resizeGL(); });
      document.addEventListener('webkitfullscreenchange', function () { updateFsLabel(); resizeGL(); });
      updateFsLabel();
    }
  }

  // ---------- WebGL setup ----------

  function compileShader(type, src) {
    var sh = gl.createShader(type);
    gl.shaderSource(sh, src);
    gl.compileShader(sh);
    if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
      console.error('shader compile error:', gl.getShaderInfoLog(sh));
    }
    return sh;
  }
  function makeProgram(vsSrc, fsSrc) {
    var prog = gl.createProgram();
    gl.attachShader(prog, compileShader(gl.VERTEX_SHADER, vsSrc));
    gl.attachShader(prog, compileShader(gl.FRAGMENT_SHADER, fsSrc));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      console.error('program link error:', gl.getProgramInfoLog(prog));
    }
    return prog;
  }

  // Full-screen quad, for the raymarch pass and the backdrop pass alike.
  var QUAD_VS = [
    'attribute vec2 aPos;',
    'void main() { gl_Position = vec4(aPos, 0.0, 1.0); }'
  ].join('\n');

  var QUAD_FS = [
    'precision highp float;',
    'uniform vec2 uResolution;',
    'uniform float uYaw;',
    'uniform float uPitch;',
    'uniform float uCameraDist;',
    'uniform float uFocal;',
    'uniform float uBaseRadius;',
    'uniform vec3 uLimbDir[9];',
    'uniform float uLimbHeight[9];',
    'uniform float uLimbPhase[9];',
    'uniform float uLimbSpeed[9];',
    'uniform float uTime;',
    'uniform vec3 uLight;',
    'uniform vec3 uBg;',
    'uniform float uTemp01;', // 0 = cold end of the reading, 1 = hot end
    'uniform float uFlowKick;', // reacts to actual drag speed
    'uniform float uTiltX;', // sloshing tilt, from recent motion
    'uniform float uTiltZ;',
    'uniform sampler2D uBgTex;',
    'uniform float uBgReady;',

    'mat3 rotY(float a) { float c = cos(a), s = sin(a); return mat3(c,0.0,-s, 0.0,1.0,0.0, s,0.0,c); }',
    'mat3 rotX(float a) { float c = cos(a), s = sin(a); return mat3(1.0,0.0,0.0, 0.0,c,s, 0.0,-s,c); }',

    'float smin(float a, float b, float k) {',
    '  float h = clamp(0.5 + 0.5*(b-a)/k, 0.0, 1.0);',
    '  return mix(b, a, h) - k*h*(1.0-h);',
    '}',
    'float sdSphere(vec3 p, float r) { return length(p) - r; }',
    'float sdCapsule(vec3 p, vec3 a, vec3 b, float ra, float rb) {',
    '  vec3 pa = p - a, ba = b - a;',
    '  float h = clamp(dot(pa,ba)/dot(ba,ba), 0.0, 1.0);',
    '  return length(pa - ba*h) - mix(ra, rb, h);',
    '}',
    // One limb's presence over time: a trapezoid, not a sine wave, so a
    // limb is clearly either out, in, or transitioning. Unchanged from v1.
    'float limbPresence(float phase, float speed) {',
    '  float c = fract(uTime*speed + phase);',
    '  return smoothstep(0.0, 0.16, c) - smoothstep(0.55, 0.72, c);',
    '}',
    // Law 1, as v1 already revised it: one generating rule (sphere +
    // limbs), fixed per-instance direction/length/phase/speed chosen once
    // in JS at load. Only limb presence still animates. v2 did not touch
    // this shape or this rule; the subtraction this build made was
    // somewhere else entirely. See docs/decisions.md.
    'float mapScene(vec3 p) {',
    '  float d = sdSphere(p, uBaseRadius);',
    '  for (int i = 0; i < 9; i++) {',
    '    float presence = limbPresence(uLimbPhase[i], uLimbSpeed[i]);',
    '    if (presence < 0.003) continue;',
    '    vec3 dir = normalize(uLimbDir[i]);',
    '    float len = uBaseRadius * (0.6 + uLimbHeight[i]) * presence;',
    '    float cap = sdCapsule(p, vec3(0.0), dir*len, uBaseRadius*0.5, uBaseRadius*0.12);',
    '    d = smin(d, cap, uBaseRadius*0.4);',
    '  }',
    '  return d;',
    '}',
    'vec3 calcNormal(vec3 p) {',
    '  vec2 e = vec2(0.001, 0.0);',
    '  return normalize(vec3(',
    '    mapScene(p+e.xyy) - mapScene(p-e.xyy),',
    '    mapScene(p+e.yxy) - mapScene(p-e.yxy),',
    '    mapScene(p+e.yyx) - mapScene(p-e.yyx)',
    '  ));',
    '}',

    // The liquid has an actual surface, not just a color painted through
    // the glass: a fill level (uTemp01 sets how high it sits, colder is
    // lower, hotter is higher) plus real wave displacement on top of that
    // level, four sine waves at different frequencies, speeds and
    // directions summed together, the standard cheap real-time way to fake
    // open water (this is what most games do; it is not a fluid
    // simulation, and nothing here claims it is). uFlowKick, fed by drag
    // in JS, drives both how fast and how big the waves are, so the
    // surface sits nearly still with no input and only agitates while
    // you actually drag it. This whole idea, a live temperature reading
    // shown as color and motion, is Law 3 from v1, relocated inside the
    // glass and given a real surface instead of just a flat tint; it is
    // not a second rule added beside the removed one.
    'float waveHeight(vec2 xz, float t, float sp) {',
    '  float h = sin(xz.x*0.10 + t*1.3*sp) * 0.5;',
    '  h += sin(xz.y*0.085 - t*1.7*sp + xz.x*0.04) * 0.4;',
    '  h += sin((xz.x + xz.y)*0.06 + t*0.9*sp) * 0.3;',
    '  h += sin(xz.x*0.16 - xz.y*0.14 + t*2.1*sp) * 0.15;',
    '  return h;',
    '}',
    // Signed distance to the wavy, tilted liquid surface: positive above
    // it (empty air), negative below it (liquid). uTiltX/uTiltZ lean the
    // whole surface toward one side under sloshing, which is what lets it
    // climb higher up one wall of the glass instead of only bobbing at a
    // fixed level.
    'float liquidSurfaceSD(vec3 p, float t, float kick, float fillY) {',
    '  float sp = 0.12 + kick * 3.4;', // barely drifting at rest, fast once dragged
    '  float amp = uBaseRadius * (0.012 + kick * 0.1);', // tiny at rest, real waves when dragged
    '  float wave = waveHeight(p.xz, t, sp) * amp;',
    '  float tilt = uTiltX*p.x + uTiltZ*p.z;',
    // Negated: the camera ray setup's screen-Y convention puts object-space
    // +Y at the visual bottom, not the top (verified empirically); this is
    // the one place that matters, since it is the only thing in the shader
    // that needs "up" to mean visual up.
    '  return -p.y - (fillY + wave + tilt);',
    '}',
    // A direct forward-difference gradient of the surface SD itself,
    // rather than a hardcoded axis assumption: correct regardless of which
    // way liquidSurfaceSD's sign convention points.
    'vec3 liquidNormal(vec3 p, float t, float kick, float fillY) {',
    '  float e = 0.6;',
    '  float d0 = liquidSurfaceSD(p, t, kick, fillY);',
    '  float dx = liquidSurfaceSD(p + vec3(e,0.0,0.0), t, kick, fillY) - d0;',
    '  float dy = liquidSurfaceSD(p + vec3(0.0,e,0.0), t, kick, fillY) - d0;',
    '  float dz = liquidSurfaceSD(p + vec3(0.0,0.0,e), t, kick, fillY) - d0;',
    '  return normalize(vec3(dx, dy, dz));',
    '}',

    'void main() {',
    '  vec2 px = gl_FragCoord.xy - 0.5*uResolution;',
    '  mat3 camRot = rotY(uYaw) * rotX(uPitch);',
    '  vec3 ro = camRot * vec3(0.0, 0.0, -uCameraDist);',
    '  vec3 rd = camRot * normalize(vec3(px.x/uFocal, -px.y/uFocal, 1.0));',

    '  float boundR = uBaseRadius * 2.8;',
    '  float b = dot(ro, rd);',
    '  float cDisc = b*b - (dot(ro,ro) - boundR*boundR);',
    '  if (cDisc < 0.0) { discard; }',

    '  float t = max(0.0, -b - sqrt(cDisc));',
    '  float tMax = -b + sqrt(cDisc);',
    '  bool hit = false;',
    '  vec3 p = ro;',
    '  for (int i = 0; i < 64; i++) {',
    '    p = ro + rd * t;',
    '    float d = mapScene(p);',
    '    if (d < 0.0015) { hit = true; break; }',
    '    t += d;',
    '    if (t > tMax) break;',
    '  }',
    '  if (!hit) { discard; }',

    '  vec3 n = calcNormal(p);',
    '  vec3 viewDir = normalize(ro - p);',
    // Lower base reflectivity than v1 (0.02 vs 0.035) and a softer top
    // sky tone, so the surface reads as clear glass at a direct angle
    // instead of frosted; it still turns reflective at grazing angles,
    // real glass does the same.
    '  float fresnel = mix(0.02, 1.0, pow(1.0 - clamp(dot(n, viewDir), 0.0, 1.0), 3.2));',

    '  vec3 reflDir = reflect(-viewDir, n);',
    '  vec3 sky = mix(vec3(0.04,0.05,0.07), vec3(0.74,0.8,0.87), smoothstep(-0.6, 0.8, reflDir.y));',

    // Bend the view ray through the glass surface, Snell's law, same as
    // v1's refraction. Colder out sits the fill line lower in the sphere,
    // hotter sits it higher; a bigger reading is more water, not just a
    // different color.
    '  vec3 refrDir = refract(-viewDir, n, 1.0/1.45);',
    // Agitation briefly lowers the resting level itself, the way real
    // water dropping into motion loses height where it started, easing
    // back once things calm down; same trapezoidal idea the limbs already
    // use for presence, a temporary dip that recovers, not a permanent one.
    // Capped so the sphere is never more than about 70% full by height:
    // fully hot still leaves a real, visible clear dome at the top.
    '  float fillY = mix(-uBaseRadius*0.5, uBaseRadius*0.4, uTemp01) - uFlowKick*(uBaseRadius*0.16);',

    // Second march, inside the shell, looking for the liquid surface.
    // max(dGlass, dLiq) is the standard CSG-intersection distance: safe to
    // step by, and it naturally stops the march the instant the ray exits
    // the glass shell without ever crossing the liquid (the empty-air
    // case, looking through the clear part above the waterline).
    '  vec3 p2 = p + refrDir * (uBaseRadius*0.02);',
    '  bool hitLiquid = false;',
    '  for (int i = 0; i < 40; i++) {',
    '    float dGlass = mapScene(p2);',
    '    if (dGlass > uBaseRadius*0.01) break;',
    '    float dLiq = liquidSurfaceSD(p2, uTime, uFlowKick, fillY);',
    '    float d = max(dGlass, dLiq);',
    '    if (d < uBaseRadius*0.0025) { hitLiquid = true; break; }',
    '    p2 += refrDir * max(d, uBaseRadius*0.012);',
    '  }',

    '  vec3 behind;',
    '  if (hitLiquid) {',
    '    vec3 liqN = liquidNormal(p2, uTime, uFlowKick, fillY);',
    '    vec3 cold = vec3(0.25, 0.5, 0.98);',
    '    vec3 hot = vec3(0.98, 0.3, 0.22);',
    '    vec3 liquidCol = mix(cold, hot, uTemp01);',
    '    vec3 liqView = normalize(-refrDir);',
    '    float liqFresnel = pow(1.0 - clamp(dot(liqN, liqView), 0.0, 1.0), 2.0);',
    '    float diff = clamp(dot(liqN, uLight)*0.5 + 0.5, 0.0, 1.0);',
    '    vec3 h2 = normalize(uLight + liqView);',
    '    float spec2 = pow(max(dot(liqN, h2), 0.0), 60.0);',

    // A body of water, not a painted surface: keep marching a short way
    // past the surface hit, through the liquid, to where it hits the
    // glass wall from the inside. That distance is how much colored
    // water is actually behind this pixel; a thin skim of it near the
    // waterline stays almost clear, and it reads more like real red or
    // blue water, not a solid tint, the further back it goes.
    '    vec3 p3 = p2 + refrDir * (uBaseRadius*0.01);',
    '    float thickness = 0.0;',
    '    for (int j = 0; j < 22; j++) {',
    '      float dG = mapScene(p3);',
    '      if (dG > uBaseRadius*0.01) break;',
    '      float step = max(-dG, uBaseRadius*0.03);',
    '      p3 += refrDir * step;',
    '      thickness += step;',
    '    }',
    '    float depthT = clamp(thickness / (uBaseRadius*1.1), 0.0, 1.0);',
    // Genuinely see-through: tint the actual room behind the glass red or
    // blue rather than fading toward flat white, so it reads as looking
    // through colored water at something, not a gradient in a vacuum.
    '    vec2 bgUvLiq = gl_FragCoord.xy / uResolution + refrDir.xy * 0.04;',
    '    vec3 seeThrough = mix(uBg, texture2D(uBgTex, clamp(bgUvLiq, 0.0, 1.0)).rgb * 0.9, uBgReady);',
    // Vivid, not washed out: thin water near the edges stays pale and
    // glassy, but a real thickness of it reads as strong, saturated color,
    // the way looking through more colored liquid gets richer, not paler.
    // Only a small fraction of the deep tone comes from what is actually
    // behind it, enough to still read as see-through, not a solid paint.
    '    vec3 shallow = mix(vec3(1.0), liquidCol, 0.4);',
    '    vec3 deep = liquidCol * 0.82 + seeThrough * 0.18;',
    '    vec3 bodyColor = mix(shallow, deep, depthT);',
    '    behind = bodyColor * (0.7 + 0.5*diff) + vec3(spec2) * 1.3 + vec3(liqFresnel) * 0.22;',
    '  } else {',
    // Looking through empty, unfilled glass: the room behind, faintly,
    // same texture the backdrop itself draws with, no separate asset.
    '    vec2 bgUv = gl_FragCoord.xy / uResolution + refrDir.xy * 0.05;',
    '    behind = mix(uBg, texture2D(uBgTex, clamp(bgUv, 0.0, 1.0)).rgb * 0.8, uBgReady);',
    '  }',

    '  vec3 col = mix(behind, sky, fresnel);',

    '  vec3 h = normalize(uLight + viewDir);',
    '  float spec = pow(max(dot(n, h), 0.0), 220.0);',
    '  col += vec3(spec) * 1.6;',

    '  float fogT = clamp((length(p - ro) - uCameraDist*0.5) / (uCameraDist*1.8), 0.0, 1.0);',
    '  col = mix(col, uBg, fogT * 0.12);',

    '  gl_FragColor = vec4(col, 1.0);',
    '}'
  ].join('\n');

  var quadProg = makeProgram(QUAD_VS, QUAD_FS);
  var quadBuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);

  // Backdrop: unchanged from v1. Johnny Ho, "Concrete hallway with dramatic
  // light and shadow," Unsplash License (free, no attribution required,
  // unwatermarked). It no longer needs to be rendered to an offscreen
  // texture: v1 did that so the glass could refract the particle flow
  // through it, and with the particles gone there is nothing left that
  // needs to sample it. It now just draws once, straight to the screen,
  // as the room the sphere sits in.
  var BG_VS = 'attribute vec2 aPos;\nvoid main() { gl_Position = vec4(aPos, 0.0, 1.0); }';
  var BG_FS = [
    'precision highp float;',
    'uniform vec2 uResolution;',
    'uniform sampler2D uBgTex;',
    'uniform float uBgReady;',
    'uniform vec3 uBg;',
    'void main() {',
    '  vec2 uv = gl_FragCoord.xy / uResolution;',
    '  vec3 base = mix(uBg, texture2D(uBgTex, uv).rgb * 0.55, uBgReady);',
    '  gl_FragColor = vec4(base, 1.0);',
    '}'
  ].join('\n');
  var bgProg = makeProgram(BG_VS, BG_FS);
  var bgTex = gl.createTexture();
  var bgReady = 0;
  gl.bindTexture(gl.TEXTURE_2D, bgTex);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([10, 10, 10, 255]));
  var bgImg = new Image();
  bgImg.onload = function () {
    gl.bindTexture(gl.TEXTURE_2D, bgTex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, bgImg);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    bgReady = 1;
  };
  bgImg.src = 'assets/concrete-hallway-light.jpg';

  var BG = [10 / 255, 10 / 255, 10 / 255];

  function drawBackdrop() {
    gl.useProgram(bgProg);
    gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf);
    var aPos = gl.getAttribLocation(bgProg, 'aPos');
    gl.enableVertexAttribArray(aPos);
    gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);
    gl.uniform2f(gl.getUniformLocation(bgProg, 'uResolution'), canvas.width, canvas.height);
    gl.uniform3f(gl.getUniformLocation(bgProg, 'uBg'), BG[0], BG[1], BG[2]);
    gl.uniform1f(gl.getUniformLocation(bgProg, 'uBgReady'), bgReady);
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, bgTex);
    gl.uniform1i(gl.getUniformLocation(bgProg, 'uBgTex'), 1);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  }

  var ratio = 900 / 600;
  function resizeGL() {
    var cssWidth;
    if (fsElement()) {
      cssWidth = Math.min(window.innerWidth, window.innerHeight * ratio);
      canvas.style.width = cssWidth + 'px';
      canvas.style.height = (cssWidth / ratio) + 'px';
    } else {
      cssWidth = canvas.clientWidth || 900;
      canvas.style.width = '';
      canvas.style.height = '';
    }
    canvas.width = Math.round(cssWidth);
    canvas.height = Math.round(cssWidth / ratio);
    gl.viewport(0, 0, canvas.width, canvas.height);
  }
  resizeGL();
  var resizeTimer = null;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(resizeGL, 120);
  });

  function draw() {
    CLOCK += 1 / 60;

    var yawVel = yaw - prevYaw;
    prevYaw = yaw;
    var angSpeed = Math.abs(yawVel) * 60; // approx radians/sec right now
    var targetKick = clamp(angSpeed * 2.2, 0, 1);
    flowKick += (targetKick - flowKick) * 0.15;

    // Tangential impulse from the current motion, a damped spring back to
    // level: this is what lets the surface tilt and climb one side of the
    // glass while dragging, and settle back afterward.
    tiltVelX += Math.sin(yaw) * yawVel * 26.0;
    tiltVelZ += Math.cos(yaw) * yawVel * 26.0;
    // A real restoring force pulling back toward level, not just decay:
    // this is what makes it settle like something gravity is acting on,
    // with a little natural overshoot, instead of gliding flat to a stop.
    tiltVelX += -tiltX * 0.09;
    tiltVelZ += -tiltZ * 0.09;
    tiltX += tiltVelX / 60;
    tiltZ += tiltVelZ / 60;
    tiltVelX *= 0.93; tiltVelZ *= 0.93;

    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(BG[0], BG[1], BG[2], 1.0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    drawBackdrop();

    gl.useProgram(quadProg);
    gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf);
    var aPos = gl.getAttribLocation(quadProg, 'aPos');
    gl.enableVertexAttribArray(aPos);
    gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);
    gl.uniform2f(gl.getUniformLocation(quadProg, 'uResolution'), canvas.width, canvas.height);
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uYaw'), yaw);
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uPitch'), pitch);
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uCameraDist'), 340);
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uFocal'), canvas.width * 0.9);
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uBaseRadius'), BASE_RADIUS);
    gl.uniform3fv(gl.getUniformLocation(quadProg, 'uLimbDir'), new Float32Array(limbDirs));
    gl.uniform1fv(gl.getUniformLocation(quadProg, 'uLimbHeight'), new Float32Array(limbHeights));
    gl.uniform1fv(gl.getUniformLocation(quadProg, 'uLimbPhase'), new Float32Array(limbPhases));
    gl.uniform1fv(gl.getUniformLocation(quadProg, 'uLimbSpeed'), new Float32Array(limbSpeeds));
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uTime'), CLOCK);
    gl.uniform3f(gl.getUniformLocation(quadProg, 'uLight'), LIGHT.x, LIGHT.y, LIGHT.z);
    gl.uniform3f(gl.getUniformLocation(quadProg, 'uBg'), BG[0], BG[1], BG[2]);
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uTemp01'), WIND.temp01);
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uFlowKick'), flowKick);
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uTiltX'), tiltX);
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uTiltZ'), tiltZ);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, bgTex);
    gl.uniform1i(gl.getUniformLocation(quadProg, 'uBgTex'), 0);
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uBgReady'), bgReady);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);

    requestAnimationFrame(draw);
  }
  draw();

})();
