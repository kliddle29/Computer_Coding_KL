# Changelog

Short entries, added as direction changed. Newest at the bottom. See
`docs/decisions.md` for the reasoning behind each one.

- **Scaffold.** Copied proven code from `trace-visual-rule-tests` into
  the required v1 structure. Nothing to screenshot yet; no merged canvas.
- **Sigil renders.** One canvas, one sigil, jitter pulled into a named
  constant. Rendered clean on the first try.
- **Behavior rule: deflection and speed color.** Generalized Test 02's
  2D row deflection into a 3D proximity rule and wired live temperature
  to wind strength. First color pass was unreadable, one flat cyan band,
  so speed now reads off deflection proximity instead of raw
  displacement.
- **Gesture mapping: drag controls yaw.** Carried Test 03's drag-to-yaw
  and Test 01's click-to-regenerate over as-is, and cut Test 01's
  ambient auto-rotation: a camera that moves on its own undercuts the
  one input.
- **Atmosphere: depth fog.** Carried Test 04's fog function over
  unchanged, applied to particles and sigil, no toggle.
- **Deploy-ready polish.** Wrote the reflections against the running
  system and confirmed all four screenshots are real captures of the
  running page. Console clean, mobile viewport has no overflow.
- **Wind readout stops guessing.** It used to show a plausible default
  number even when the live fetch failed. Now it holds at `--` until
  the fetch succeeds, or says `offline` if it doesn't. The flow still
  runs either way, but the display never fakes being live.
- **Cut to one gesture.** Removed click/Enter/Space-to-regenerate;
  drag &rarr; yaw is now the only input. The two-input reading was
  defensible, but it left an ambiguity open in graded work that didn't
  need to be.
- **Cite the wind data source; rewrite copy.** Added a caption under the
  canvas naming Open-Meteo and the exact request, and rewrote the
  reflections, docs, and code comments to cut em dashes and other
  AI-writing tells.
- **Link the data source.** The Open-Meteo mention in the caption was
  plain text; made it a real link to open-meteo.com, styled to match
  the page instead of default blue.
- **Fullscreen toggle.** Added a button that requests fullscreen on the
  stage; `fitCanvas()` now sizes off the viewport while fullscreen is
  active instead of a container width that isn't reliable in that state.
  An automated click confirmed the browser correctly refuses the
  request (fullscreen needs a real user gesture); the layout itself
  was checked by applying the same styles directly and screenshotting
  the result. Still needs one real click to confirm end to end.
- **More faces, more resistance, trailing streamlines.** Subdivided the
  icosahedron twice (20 to 320 faces) instead of swapping in a new base
  shape, added a thin stroke per face so that many facets still read
  clearly, and switched particle rendering from flat dots to short
  fading trails, closer to the proposal's own reference image. Raised
  `DEFLECT_STRENGTH`, `FLOOR_PUSH`, and `INFLUENCE_R` for a stronger
  bend, retuned `SPEED_BOOST`/`MAX_SPEED` to match, and layered a smooth
  per-particle wobble on top of the deflection offset for wind noise.
  Updated the reflection's "drift toward generic" line: it named a dot
  cloud, and the render doesn't draw dots anymore.
- **Protrusions, a glossy highlight, faster resistance.** Gave 4 of the
  12 base vertices an extra length multiplier at generation time, so the
  form reads as crystalline rather than a smooth gem; still one rule,
  still fixed after load. Added a specular term to the shading (same
  light, same normal, fixed view direction) for a glossier, icier look.
  Pushed `FLOW_UNIT`, `EASE`, `DEFLECT_STRENGTH`, and `NOISE_AMP` up
  again for faster, more turbulent movement. Did not use the watermarked
  stock photo requested as a background, and did not make the solid
  deform over time; both are real open questions, not implemented
  silently either way.
- **Limbs, smoothed.** The single-vertex spikes read as angular, not the
  smooth protrusions asked for. Moved the bump to run after subdivision,
  across every vertex, falling off with angular distance from a handful
  of random centers, so the base stays round and the limbs actually
  taper. Recreated the requested background mood (cool light, upper
  right) as a CSS gradient over the existing concrete asset instead of
  either photo sent this session, both watermarked stock images.
- **Overshot on limb length, pulled it back.** A follow-up asked for
  "way more" limb length; the result read as a starfish, not a sigil
  with a few smooth additions. Reverted the limb height, angular radius,
  and subdivision count to the prior values (see the commit right
  before this one for exactly what they were). Kept the paler, glossier
  shading and softened the facet stroke further, since a smoother
  surface reads better with less visible faceting between triangles.
- **Rewrote the renderer in WebGL.** Requested directly, tradeoffs
  stated and accepted. The solid is now a raymarched signed-distance
  field (sphere plus limb capsules, smooth-blended) with real Fresnel
  reflection and Snell's-law refraction of the particle flow through the
  surface, instead of flat-shaded Canvas 2D triangles. Raw WebGL and
  hand-written GLSL, no Three.js. Measured 60fps sustained. Law 5's
  "that's the only shading rule" no longer holds, since reflection and
  refraction are the actual material now, not an addition to flat
  shading; the page's rules list says so.
- **Brightened the glass, added the concrete backdrop and light shaft.**
  Raised the sky reflection color and removed some flattening darkening
  that was making the material read as dull rather than glassy. Loaded
  `assets/concrete-background.png`, the system's own asset, as a real
  WebGL texture behind the particle flow, with a procedural diagonal
  light shaft over it. That shaft is what shows "through" the glass via
  the refraction pass, not a separate effect. Still not either of the
  two watermarked stock photos sent this session; still not files this
  session could read from disk.
- **Limb presence now animates.** A follow-up asked for more limbs that
  can disappear, specifically so the mechanism reads as obvious. Raised
  the limb count to 9 and gave each one a fixed-cycle presence (a
  trapezoid in time, not a sine wave, so a limb is clearly out, in, or
  transitioning): one clock drives all of them, and each limb's
  direction, length, phase, and speed are still chosen once, at
  generation. This is a second, separate departure from Law 1's literal
  text, past the SDF change above; both are named directly in
  `decisions.md` rather than argued around.
- **Found and fixed a caching bug that made recent verification
  unreliable.** The browser was serving a stale `index.html`/`script.js`
  across several rounds of edits and reloads, with no error to say so;
  separately, `console.log` from the page script wasn't reaching this
  session's log reader, for the same root cause (a JS world boundary)
  that made an earlier `window.__debug` global invisible while DOM reads
  stayed reliable throughout. Fixed for this session with a cache-busting
  query during development (removed before this commit); re-verified the
  recent shading and shaft-position fixes under a real fresh load, and
  they hold up.
- **Swapped in a real licensed photo, retired the procedural shaft.**
  Found a freely-licensed match for the mood of the two watermarked
  reference photos (Johnny Ho, "Concrete hallway with dramatic light and
  shadow," Unsplash License) and downloaded it after explicit selection
  from a shortlist. It replaces `concrete-background.png` as the
  backdrop in both the CSS background and the WebGL refraction texture.
  Removed the procedural diagonal light shaft from both the CSS and GLSL
  versions, since it existed only as a stand-in for a photo like this
  one; running both at once would have meant two competing light
  directions in the same frame.
- **Simplified the reflection; audited against the master reference
  directly.** Split the v1 reflection into four shorter paragraphs and
  cut sentence length instead of just trimming words. Re-checked the
  live build against `trace_master_reference.md` itself rather than
  memory: the speed ramp's five hex stops, the #0A0A0A primary, the
  monospace-only type rule, Law 2, Law 4, and Q08's camera-only drag
  rule all match exactly. Laws 1 and 5 were already known departures;
  found one new one, the background is a real photo now where that
  document specifies procedural only, and documented it the same way on
  request rather than reverting it.

## v2

- **Scaffolded v2.** Duplicated the whole v1 folder and git history into
  a new one rather than editing v1 in place, per the brief's own
  workflow. Added a second dev-server entry so both versions still run
  independently.
- **Removed the particles; replaced them with liquid in the glass.**
  The one subtraction v2's brief asks for. What the particles used to
  do, read a live temperature as color and motion, moved inside the
  glass instead: same rule, relocated, not a second one added beside
  the one removed. Cutting the particles also cut Law 4's deflection
  rule and, with it, v1's whole original thesis; named directly in
  `docs/decisions.md` rather than glossed over.
- **Rebuilt the liquid twice more after that.** A flat color-through-
  refraction version read as a solid tinted ball; a higher-frequency
  version meant to fix that read as a dimpled golf ball instead. Both
  were replaced once a reference photo made the actual ask clear: a
  real fill level with a wavy surface, not a color painted through the
  glass. That meant a second raymarch inside the shell, against a
  height field standing in for water. Found and fixed a real bug along
  the way: the fill level rendered upside down, because the camera
  ray's screen-to-world convention puts positive object-space Y at the
  visual bottom, not the top, and nothing before this had ever depended
  on absolute up or down.
- **Added depth-graded color and a stronger, calmer flow.** The liquid
  now reads how much water is actually behind a given point, so a thin
  edge stays nearly clear and a deep stretch reads richer, closer to
  real colored water than a flat tint. Wave speed and size are tied
  directly to how fast the camera is actually being dragged, so it
  sits nearly still with no input and only agitates once dragged, on
  direct request after an earlier pass left it too restless at rest.
- **Gave the liquid a real restoring spring, and reopened full orbit.**
  The tilt that lets water slosh up one wall now settles back with an
  actual spring force and a bit of natural overshoot, not just decay,
  the closest this gets to "gravity" without claiming to simulate it.
  Vertical drag now also drives pitch, on direct request; this reopens
  the single-axis discipline named as v1's strongest surviving rule
  earlier in this same document, so the page's own reflection panel was
  corrected to say what actually held: a drag only ever moves the
  camera, never the single axis specifically.
- **Rewrote the renderer in WebGPU: real particle physics, not an
  analytic wave.** Tradeoffs (a different graphics API, real browser-
  support gaps, no fallback) stated and accepted before starting. A GPU
  compute pass now simulates real particles, gravity, pairwise
  repulsion, and collision against the solid's own SDF, screen-space
  blurred and shaded into a continuous surface instead of visible dots.
  Kept the old WebGL version as `script.webgl-v2.bak.js` rather than
  deleting it. Retuned twice more on direct request: drag-driven force
  cut sharply and a true velocity freeze added so the liquid actually
  sits still instead of perpetually re-jittering, and its color capped
  short of fully opaque so it reads as clear colored water, not paint.
- **Reversed which part of the system moves.** The camera is now fixed
  and never rotates; dragging rotates the solid itself, evaluated by
  transforming each raymarched point into the solid's own rotating
  frame before its SDF runs, in both the render pass and the compute
  pass's boundary check. The liquid stays entirely in the fixed camera
  frame and is never rotated, which is what lets it stay level while the
  solid visibly turns in front of it. Named directly as a real reversal
  of the camera-orbits-a-fixed-object rule this project held since v1's
  Q06 and Law 1, not folded quietly into old language.
- **Pulled the particle simulation back out.** It never looked clear or
  crisp next to the actual reference photos. Replaced with a direct
  analytic liquid surface again (a height field raymarched as a second
  surface, same category as the very first version of this liquid),
  combined correctly this time with the fixed-camera model, and shaded
  glossier: a broader Fresnel sheen, two specular highlights instead of
  one, and chromatic aberration on the refracted backdrop. Gesture
  simplified back to yaw only, on request, since one axis made the
  slosh reaction easier to tune. Fixed two real bugs the rewrite
  surfaced: a uniform buffer that did not grow to match a larger struct,
  and a WGSL rule against sampling a texture inside non-uniform control
  flow. Also found that this session's error-reading tool briefly showed
  stale cached errors across several real code changes; confirmed fixes
  by checking the served file directly instead.
- **Cut the liquid entirely; the solid is tinted glass now.** On direct
  request, scrapped the liquid surface (fill level, tilt, wave, the
  second raymarch for it) and replaced it with one material: the shell
  itself tinted blue to red by the live temperature, depth-graded by a
  thickness march so it reads clear near the edge and richly saturated
  through the middle, real colored glass rather than clear glass around
  a separate liquid. Adapted one technique, chromatic aberration on the
  refracted sample, from a screen-space "liquid glass" CSS library sent
  as a reference; that library is a different, 2D DOM-overlay technique
  and was not ported wholesale. Investigated a fullscreen bug report
  (broken transparency and shading); could not reproduce directly since
  this session's automation cannot trigger a real Fullscreen API
  gesture, tried and then backed out a defensive context-reconfigure
  fix after it coincided with an unrelated render hang during testing.
  Also hit the stale-console-cache issue again, this time severely
  enough that only closing and reopening the browser tab resolved it.
