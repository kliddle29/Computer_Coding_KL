# Critique notes: v2 against the course's own lens

Self-assessment, written after the system was running. This file changed
more than once as the build changed, in both v1 and v2; it describes the
system as it stands at the last commit, not its whole history.
`decisions.md` has that history.

## Clarity: can we tell what the system rules are by watching it run?

The color itself reads clearly: blue toward cold, red toward hot, one
live reading, no second source. What's genuinely harder to read now
than in v1: there is no more visible mechanism connecting this system
back to its own stated purpose. v1's thesis was legible on sight, a
flow bending around a fixed shape. v2 cut that flow, and what's left, a
solid piece of colored glass, doesn't explain itself as an "identity
system" the way the deflection rule used to; it explains itself as a
temperature gauge shaped like a gem, a different and smaller claim.

## Restraint: does it avoid piling on effects and noise?

Less than v1, worth stating directly, though the closing state is
simpler than several points this build passed through. The one
required subtraction genuinely happened: the particles, the flow
field, the whole deflection rule are gone, not hidden. What replaced
them took two real detours before landing anywhere restrained: a full
GPU compute simulation with a six-pass screen-space renderer, then a
raymarched analytic liquid surface with its own tilt and wave physics,
both tried, both cut again, on direct request, for not looking clear or
crisp enough against the actual reference. What is actually running now
is one rule, temperature reads as color, tinting one material instead
of driving a second one, which is closer to what "rebuilt to carry more
weight" should have meant from the start. The gesture history is
similarly non-monotonic: single axis, reopened to full orbit, narrowed
back to single axis. Two constraints did end up genuinely, permanently
loosened: the camera-fixed, object-fixed relationship held since v1's
Q06 and Law 1 was reversed outright, and the renderer changed graphics
APIs mid-build. Both are named on the page and in `decisions.md`, not
quietly absorbed.

## Intention: do the controls and behaviors feel chosen and coherent?

The live measurement is still real and still singular: one temperature
reading, one color rule, not two unrelated numbers or a color plus a
separate simulated behavior. The reversed camera relationship is a
genuine intentional choice, not an accident, made to match a specific
requested feeling, holding an object in your hand and turning it, not
moving your head around a fixed one. The open gap is the same one
Restraint just named from a different angle: coherent with itself, not
with the system's original stated thesis, since that thesis was
specifically about flow and deflection. "A solid piece of glass that
reads temperature as its own color, turned in your hand" is a real,
defensible system on its own terms; it is a different, smaller claim
than v1 made, and the honest move is calling it that rather than
letting v1's language quietly carry over unchanged.

## Craft: does it run reliably, respond predictably, feel cared for?

Simpler now than at any point since the WebGPU rewrite began: one
raymarch pass, one material, no compute pass, no particle buffer, no
blur passes. Real bugs surfaced and got fixed along the way, worth
naming precisely rather than glossing over: an inverted fill level from
a screen-to-world sign convention, back when there still was a fill
level; a uniform buffer that did not grow to match a larger struct,
throwing a hard error every frame; and a WGSL rule against sampling a
texture inside a branch whose condition depends on a raymarch result.
Separately, this session's own error-reading tool repeatedly showed
stale, cached error text that looked identical across several real code
changes and even across closing and reopening tabs; real fixes were
confirmed by checking the served file's content directly and, later, by
opening a genuinely fresh tab, not by trusting that tool's live-error
claim. A fullscreen bug report (broken transparency and shading) could
not be directly reproduced, since this session's automation cannot
trigger the real Fullscreen API; a defensive fix was tried, appeared to
coincide with an unrelated render hang during testing, and was backed
out unconfirmed either way. That remains a real, open item to check by
hand, not a settled fix. WebGPU itself is still the largest standing
craft risk: real, meaningfully weaker browser support than WebGL,
accepted knowingly, with a plain-text fallback message if it is
unavailable rather than a silent failure, but still a real chance this
does not run at all somewhere it needs to. The working WebGL version
stays in the repo as a fallback for exactly that reason. Frame rate was
not measured against a specific target this round.
