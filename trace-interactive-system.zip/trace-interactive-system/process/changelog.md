# Changelog

Short entries, added as direction changed. Newest at the bottom. See
`docs/decisions.md` for the reasoning behind each one.

- **Scaffold.** Copied proven code from `trace-visual-rule-tests` into
  the required v1 structure. Nothing to screenshot yet; no merged canvas.
- **Sigil renders.** One canvas, one sigil, jitter pulled into a named
  constant. Rendered clean on the first try.
- **Behavior rule: deflection and speed color.** Generalized Test 02's
  2D row deflection into a 3D proximity rule and wired live temperature
  to wind strength. First color pass was unreadable, one flat cyan band,
  so speed now reads off deflection proximity instead of raw
  displacement.
- **Gesture mapping: drag controls yaw.** Carried Test 03's drag-to-yaw
  and Test 01's click-to-regenerate over as-is, and cut Test 01's
  ambient auto-rotation: a camera that moves on its own undercuts the
  one input.
- **Atmosphere: depth fog.** Carried Test 04's fog function over
  unchanged, applied to particles and sigil, no toggle.
- **Deploy-ready polish.** Wrote the reflections against the running
  system and confirmed all four screenshots are real captures of the
  running page. Console clean, mobile viewport has no overflow.
- **Wind readout stops guessing.** It used to show a plausible default
  number even when the live fetch failed. Now it holds at `--` until
  the fetch succeeds, or says `offline` if it doesn't. The flow still
  runs either way, but the display never fakes being live.
- **Cut to one gesture.** Removed click/Enter/Space-to-regenerate;
  drag &rarr; yaw is now the only input. The two-input reading was
  defensible, but it left an ambiguity open in graded work that didn't
  need to be.
- **Cite the wind data source; rewrite copy.** Added a caption under the
  canvas naming Open-Meteo and the exact request, and rewrote the
  reflections, docs, and code comments to cut em dashes and other
  AI-writing tells.
- **Link the data source.** The Open-Meteo mention in the caption was
  plain text; made it a real link to open-meteo.com, styled to match
  the page instead of default blue.
- **Fullscreen toggle.** Added a button that requests fullscreen on the
  stage; `fitCanvas()` now sizes off the viewport while fullscreen is
  active instead of a container width that isn't reliable in that state.
  An automated click confirmed the browser correctly refuses the
  request (fullscreen needs a real user gesture); the layout itself
  was checked by applying the same styles directly and screenshotting
  the result. Still needs one real click to confirm end to end.
- **More faces, more resistance, trailing streamlines.** Subdivided the
  icosahedron twice (20 to 320 faces) instead of swapping in a new base
  shape, added a thin stroke per face so that many facets still read
  clearly, and switched particle rendering from flat dots to short
  fading trails, closer to the proposal's own reference image. Raised
  `DEFLECT_STRENGTH`, `FLOOR_PUSH`, and `INFLUENCE_R` for a stronger
  bend, retuned `SPEED_BOOST`/`MAX_SPEED` to match, and layered a smooth
  per-particle wobble on top of the deflection offset for wind noise.
  Updated the reflection's "drift toward generic" line: it named a dot
  cloud, and the render doesn't draw dots anymore.
- **Protrusions, a glossy highlight, faster resistance.** Gave 4 of the
  12 base vertices an extra length multiplier at generation time, so the
  form reads as crystalline rather than a smooth gem; still one rule,
  still fixed after load. Added a specular term to the shading (same
  light, same normal, fixed view direction) for a glossier, icier look.
  Pushed `FLOW_UNIT`, `EASE`, `DEFLECT_STRENGTH`, and `NOISE_AMP` up
  again for faster, more turbulent movement. Did not use the watermarked
  stock photo requested as a background, and did not make the solid
  deform over time; both are real open questions, not implemented
  silently either way.
- **Limbs, smoothed.** The single-vertex spikes read as angular, not the
  smooth protrusions asked for. Moved the bump to run after subdivision,
  across every vertex, falling off with angular distance from a handful
  of random centers, so the base stays round and the limbs actually
  taper. Recreated the requested background mood (cool light, upper
  right) as a CSS gradient over the existing concrete asset instead of
  either photo sent this session, both watermarked stock images.
- **Overshot on limb length, pulled it back.** A follow-up asked for
  "way more" limb length; the result read as a starfish, not a sigil
  with a few smooth additions. Reverted the limb height, angular radius,
  and subdivision count to the prior values (see the commit right
  before this one for exactly what they were). Kept the paler, glossier
  shading and softened the facet stroke further, since a smoother
  surface reads better with less visible faceting between triangles.
- **Rewrote the renderer in WebGL.** Requested directly, tradeoffs
  stated and accepted. The solid is now a raymarched signed-distance
  field (sphere plus limb capsules, smooth-blended) with real Fresnel
  reflection and Snell's-law refraction of the particle flow through the
  surface, instead of flat-shaded Canvas 2D triangles. Raw WebGL and
  hand-written GLSL, no Three.js. Measured 60fps sustained. Law 5's
  "that's the only shading rule" no longer holds, since reflection and
  refraction are the actual material now, not an addition to flat
  shading; the page's rules list says so.
- **Brightened the glass, added the concrete backdrop and light shaft.**
  Raised the sky reflection color and removed some flattening darkening
  that was making the material read as dull rather than glassy. Loaded
  `assets/concrete-background.png`, the system's own asset, as a real
  WebGL texture behind the particle flow, with a procedural diagonal
  light shaft over it. That shaft is what shows "through" the glass via
  the refraction pass, not a separate effect. Still not either of the
  two watermarked stock photos sent this session; still not files this
  session could read from disk.
- **Limb presence now animates.** A follow-up asked for more limbs that
  can disappear, specifically so the mechanism reads as obvious. Raised
  the limb count to 9 and gave each one a fixed-cycle presence (a
  trapezoid in time, not a sine wave, so a limb is clearly out, in, or
  transitioning): one clock drives all of them, and each limb's
  direction, length, phase, and speed are still chosen once, at
  generation. This is a second, separate departure from Law 1's literal
  text, past the SDF change above; both are named directly in
  `decisions.md` rather than argued around.
- **Found and fixed a caching bug that made recent verification
  unreliable.** The browser was serving a stale `index.html`/`script.js`
  across several rounds of edits and reloads, with no error to say so;
  separately, `console.log` from the page script wasn't reaching this
  session's log reader, for the same root cause (a JS world boundary)
  that made an earlier `window.__debug` global invisible while DOM reads
  stayed reliable throughout. Fixed for this session with a cache-busting
  query during development (removed before this commit); re-verified the
  recent shading and shaft-position fixes under a real fresh load, and
  they hold up.
- **Swapped in a real licensed photo, retired the procedural shaft.**
  Found a freely-licensed match for the mood of the two watermarked
  reference photos (Johnny Ho, "Concrete hallway with dramatic light and
  shadow," Unsplash License) and downloaded it after explicit selection
  from a shortlist. It replaces `concrete-background.png` as the
  backdrop in both the CSS background and the WebGL refraction texture.
  Removed the procedural diagonal light shaft from both the CSS and GLSL
  versions, since it existed only as a stand-in for a photo like this
  one; running both at once would have meant two competing light
  directions in the same frame.
- **Simplified the reflection; audited against the master reference
  directly.** Split the v1 reflection into four shorter paragraphs and
  cut sentence length instead of just trimming words. Re-checked the
  live build against `trace_master_reference.md` itself rather than
  memory: the speed ramp's five hex stops, the #0A0A0A primary, the
  monospace-only type rule, Law 2, Law 4, and Q08's camera-only drag
  rule all match exactly. Laws 1 and 5 were already known departures;
  found one new one, the background is a real photo now where that
  document specifies procedural only, and documented it the same way on
  request rather than reverting it.
