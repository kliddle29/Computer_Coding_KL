// TRACE / Interactive System Build v1
// WebGL rewrite: the solid is a raymarched signed-distance surface (a
// sphere with smooth limb bumps blended in) instead of a flat-shaded
// triangle mesh, shaded with real Fresnel-weighted reflection and
// refraction. The particle flow keeps its original physics; only how
// everything gets drawn changed. See docs/decisions.md for why and what
// this trades away.

(function () {
  'use strict';

  var canvas = document.getElementById('stage');
  var gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
  if (!gl) {
    canvas.parentNode.insertBefore(
      document.createTextNode('WebGL is not available in this browser.'),
      canvas
    );
    return;
  }

  // ---------- shared math ----------

  function normalize(v) {
    var l = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z) || 1;
    return { x: v.x / l, y: v.y / l, z: v.z / l };
  }
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
  function rotateYP(p, yaw, pitch) {
    var cy = Math.cos(yaw), sy = Math.sin(yaw);
    var x1 = p.x * cy + p.z * sy;
    var z1 = -p.x * sy + p.z * cy;
    var y1 = p.y;
    var cp = Math.cos(pitch), sp = Math.sin(pitch);
    return { x: x1, y: y1 * cp - z1 * sp, z: y1 * sp + z1 * cp };
  }

  // ---------- Law 1: the solid's parameters, chosen once, at generation ----------
  // Built as a signed-distance field now instead of a vertex mesh: a sphere
  // with a handful of limb bumps smooth-blended in. Same rule as every
  // earlier version of this build: random choices happen once, here, and
  // nothing about the solid changes after this point. See decisions.md for
  // why the mesh became an SDF.

  // NOTE ON LAW 1: limb *presence* now cycles over time (below, uTime-driven
  // in the shader) so more than one protrusion is never on screen at once
  // and each one's arrival/departure is legible, not a static pile-up. That
  // is a deliberate departure from Law 1's literal text ("fixed once
  // generated... never edits a vertex after that") taken on direct request.
  // What's still true to the spirit of Law 1: the animation is one rule,
  // driven by a single clock, not arbitrary per-frame randomness, and the
  // per-limb direction/length/phase/speed values are still chosen once, at
  // generation, and never change after that. See docs/decisions.md.

  var JITTER_RATIO = 0.15;
  var BASE_RADIUS = 60 * (1 + (Math.random() * 2 - 1) * JITTER_RATIO);
  var LIMB_COUNT = 9;
  var limbDirs = [];    // flattened [x,y,z, x,y,z, ...] for the shader uniform
  var limbHeights = [];  // one extra-length fraction per limb
  var limbPhases = [];   // where in its cycle each limb starts
  var limbSpeeds = [];   // how fast each limb cycles (cycles/second-ish)
  (function generateLimbs() {
    for (var i = 0; i < LIMB_COUNT; i++) {
      var d = normalize({ x: Math.random() * 2 - 1, y: Math.random() * 2 - 1, z: Math.random() * 2 - 1 });
      limbDirs.push(d.x, d.y, d.z);
      limbHeights.push(0.35 + Math.random() * 0.55);
      limbPhases.push(Math.random());
      limbSpeeds.push(0.05 + Math.random() * 0.04);
    }
  })();

  var LIGHT = normalize({ x: 0.35, y: 0.9, z: 0.5 });

  // ---------- wind (Q07: a live reading sets flow strength) ----------
  // Unchanged from the Canvas 2D version: the readout shows a number only
  // once the fetch succeeds, never a guess, and says "offline" if it fails.

  var windOut = document.getElementById('wind-temp-out');
  var WIND = { tempF: null, scale: 1 };
  function tempToScale(t) { return clamp(0.6 + ((t - 40) / 80) * 1.6, 0.6, 2.2); }
  function setWind(t) {
    WIND.tempF = t;
    WIND.scale = tempToScale(t);
    if (windOut) windOut.textContent = Math.round(t) + '°F';
  }
  fetch('https://api.open-meteo.com/v1/forecast?latitude=33.4484&longitude=-112.0740&current=temperature_2m&temperature_unit=fahrenheit')
    .then(function (r) { return r.json(); })
    .then(function (data) {
      if (data && data.current && typeof data.current.temperature_2m === 'number') {
        setWind(data.current.temperature_2m);
      } else {
        throw new Error('unexpected response shape');
      }
    })
    .catch(function () {
      if (windOut) windOut.textContent = 'offline';
    });

  // ---------- speed → color (Law 3) ----------

  var SPEED_STOPS = [[30, 40, 180], [30, 180, 220], [60, 200, 80], [230, 210, 40], [220, 60, 40]];
  function speedColor(u) {
    u = clamp(u, 0, 1);
    var seg = u * (SPEED_STOPS.length - 1);
    var i = Math.min(SPEED_STOPS.length - 2, Math.floor(seg)), f = seg - i;
    var a = SPEED_STOPS[i], b = SPEED_STOPS[i + 1];
    return [
      (a[0] + (b[0] - a[0]) * f) / 255,
      (a[1] + (b[1] - a[1]) * f) / 255,
      (a[2] + (b[2] - a[2]) * f) / 255
    ];
  }

  // ---------- atmosphere: depth fog (Law-adjacent, kept from the prior version) ----------

  var BG = [10 / 255, 10 / 255, 10 / 255];
  var FOG_NEAR = -60, FOG_FAR = 220;
  function fog(col, depth) {
    var t = clamp((depth - FOG_NEAR) / (FOG_FAR - FOG_NEAR), 0, 1);
    return [
      col[0] + (BG[0] - col[0]) * t,
      col[1] + (BG[1] - col[1]) * t,
      col[2] + (BG[2] - col[2]) * t
    ];
  }

  // ---------- particles: Law 2 (fixed world-axis flow) + Law 4 (deflection) ----------
  // Physics unchanged from the Canvas 2D build; only the final draw call
  // (WebGL points instead of canvas arcs) is new.

  var N = 260;
  var SPAN = 220;
  var R_SPAWN = 130;
  var INFLUENCE_R = 140;
  var DEFLECT_STRENGTH = 150;
  var FLOOR_PUSH = 0.22;
  var EASE = 0.19;
  var FLOW_UNIT = 2.1;
  var SPEED_BOOST = 115;
  var MAX_SPEED = 85;
  var NOISE_AMP = 16;
  var CLOCK = 0;

  var particles = [];
  function spawn(p) {
    var a = Math.random() * Math.PI * 2;
    var r = Math.random() * R_SPAWN;
    p.x = -SPAN + Math.random() * 40;
    p.baseY = Math.cos(a) * r;
    p.baseZ = Math.sin(a) * r;
    p.offY = 0;
    p.offZ = 0;
    p.baseSpeed = 0.75 + Math.random() * 0.5;
    p.nPhaseY = Math.random() * Math.PI * 2;
    p.nPhaseZ = Math.random() * Math.PI * 2;
    p.nFreq = 0.5 + Math.random() * 0.7;
  }
  for (var pi = 0; pi < N; pi++) {
    var p0 = {};
    spawn(p0);
    p0.x = -SPAN + Math.random() * (SPAN * 2);
    particles.push(p0);
  }

  function stepParticle(p) {
    var dx = p.baseSpeed * WIND.scale * FLOW_UNIT;
    p.x += dx;
    var distC = Math.sqrt(p.x * p.x + p.baseY * p.baseY + p.baseZ * p.baseZ);
    var influence = clamp(1 - distC / INFLUENCE_R, 0, 1);
    var perpLen = Math.sqrt(p.baseY * p.baseY + p.baseZ * p.baseZ) || 0.0001;
    var dirY = p.baseY / perpLen, dirZ = p.baseZ / perpLen;
    var target = influence > 0 ? influence * DEFLECT_STRENGTH + FLOOR_PUSH * DEFLECT_STRENGTH * influence : 0;
    p.offY += (target * dirY - p.offY) * EASE;
    p.offZ += (target * dirZ - p.offZ) * EASE;
    var noiseY = Math.sin(CLOCK * p.nFreq + p.nPhaseY) * NOISE_AMP;
    var noiseZ = Math.cos(CLOCK * p.nFreq * 0.83 + p.nPhaseZ) * NOISE_AMP;
    var y = p.baseY + p.offY + noiseY, z = p.baseZ + p.offZ + noiseZ;
    var speed = dx + influence * SPEED_BOOST;
    if (p.x > SPAN) spawn(p);
    return { x: p.x, y: y, z: z, speed: speed };
  }

  // ---------- gesture: drag → yaw, the only input this system takes (Q06) ----------

  canvas.setAttribute('role', 'img');
  canvas.setAttribute('aria-label',
    'TRACE. A glass-like solid inside a field of streamlines that deflect around it. ' +
    'Drag to orbit the camera; not adjustable by keyboard.');

  var yaw = 0.6, pitch = -0.2;
  var dragging = false, lastX = null;
  function toLocalX(e) {
    var rect = canvas.getBoundingClientRect();
    var ev = e.touches ? e.touches[0] : e;
    return (ev.clientX - rect.left) * (canvas.width / rect.width);
  }
  function pressStart(e) { dragging = true; lastX = toLocalX(e); }
  function pressMove(e) {
    if (!dragging) return;
    var x = toLocalX(e);
    yaw += (x - lastX) * 0.01;
    lastX = x;
  }
  function pressEnd() { dragging = false; lastX = null; }
  canvas.addEventListener('mousedown', pressStart);
  window.addEventListener('mousemove', pressMove);
  window.addEventListener('mouseup', pressEnd);
  canvas.addEventListener('touchstart', pressStart, { passive: true });
  canvas.addEventListener('touchmove', pressMove, { passive: true });
  window.addEventListener('touchend', pressEnd);

  // ---------- fullscreen toggle (a viewing utility, not part of the gesture language) ----------

  var stageEl = document.querySelector('.stage');
  var fsBtn = document.getElementById('fullscreen-toggle');
  var fsRequest = stageEl.requestFullscreen || stageEl.webkitRequestFullscreen;
  var fsExit = document.exitFullscreen || document.webkitExitFullscreen;
  function fsElement() { return document.fullscreenElement || document.webkitFullscreenElement || null; }
  if (fsBtn) {
    if (!fsRequest) {
      fsBtn.style.display = 'none';
    } else {
      fsBtn.addEventListener('click', function () {
        if (fsElement()) fsExit.call(document); else fsRequest.call(stageEl);
      });
      var updateFsLabel = function () { fsBtn.textContent = fsElement() ? 'exit fullscreen' : 'fullscreen'; };
      document.addEventListener('fullscreenchange', function () { updateFsLabel(); resizeGL(); });
      document.addEventListener('webkitfullscreenchange', function () { updateFsLabel(); resizeGL(); });
      updateFsLabel();
    }
  }

  // ---------- WebGL setup ----------

  function compileShader(type, src) {
    var sh = gl.createShader(type);
    gl.shaderSource(sh, src);
    gl.compileShader(sh);
    if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
      console.error('shader compile error:', gl.getShaderInfoLog(sh));
    }
    return sh;
  }
  function makeProgram(vsSrc, fsSrc) {
    var prog = gl.createProgram();
    gl.attachShader(prog, compileShader(gl.VERTEX_SHADER, vsSrc));
    gl.attachShader(prog, compileShader(gl.FRAGMENT_SHADER, fsSrc));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      console.error('program link error:', gl.getProgramInfoLog(prog));
    }
    return prog;
  }

  // Full-screen quad, for the raymarch pass.
  var QUAD_VS = [
    'attribute vec2 aPos;',
    'void main() { gl_Position = vec4(aPos, 0.0, 1.0); }'
  ].join('\n');

  var QUAD_FS = [
    'precision highp float;',
    'uniform vec2 uResolution;',
    'uniform float uYaw;',
    'uniform float uPitch;',
    'uniform float uCameraDist;',
    'uniform float uFocal;',
    'uniform float uBaseRadius;',
    'uniform vec3 uLimbDir[9];',
    'uniform float uLimbHeight[9];',
    'uniform float uLimbPhase[9];',
    'uniform float uLimbSpeed[9];',
    'uniform float uTime;',
    'uniform vec3 uLight;',
    'uniform sampler2D uSceneTex;',
    'uniform vec3 uBg;',

    'mat3 rotY(float a) { float c = cos(a), s = sin(a); return mat3(c,0.0,-s, 0.0,1.0,0.0, s,0.0,c); }',
    'mat3 rotX(float a) { float c = cos(a), s = sin(a); return mat3(1.0,0.0,0.0, 0.0,c,s, 0.0,-s,c); }',

    'float smin(float a, float b, float k) {',
    '  float h = clamp(0.5 + 0.5*(b-a)/k, 0.0, 1.0);',
    '  return mix(b, a, h) - k*h*(1.0-h);',
    '}',
    'float sdSphere(vec3 p, float r) { return length(p) - r; }',
    'float sdCapsule(vec3 p, vec3 a, vec3 b, float ra, float rb) {',
    '  vec3 pa = p - a, ba = b - a;',
    '  float h = clamp(dot(pa,ba)/dot(ba,ba), 0.0, 1.0);',
    '  return length(pa - ba*h) - mix(ra, rb, h);',
    '}',
    // One limb's presence over time: a trapezoid, not a sine wave, so a
    // limb is clearly either out, in, or transitioning, never lingering at
    // a hard-to-read halfway state. Driven only by uTime, one clock shared
    // by every limb; the per-limb phase/speed offsets were chosen once, at
    // generation, so each limb's cycle is fixed even though its presence
    // is not.
    'float limbPresence(float phase, float speed) {',
    '  float c = fract(uTime*speed + phase);',
    '  return smoothstep(0.0, 0.16, c) - smoothstep(0.55, 0.72, c);',
    '}',
    // Law 1, as revised for this version: one generating rule (sphere +
    // limbs), with fixed per-instance direction/length/phase/speed chosen
    // once in JS at load. What is no longer fixed is which limbs are
    // currently extended: that is the one deliberate, documented exception
    // to "never edits a vertex after generation." See docs/decisions.md.
    'float mapScene(vec3 p) {',
    '  float d = sdSphere(p, uBaseRadius);',
    '  for (int i = 0; i < 9; i++) {',
    '    float presence = limbPresence(uLimbPhase[i], uLimbSpeed[i]);',
    '    if (presence < 0.003) continue;',
    '    vec3 dir = normalize(uLimbDir[i]);',
    '    float len = uBaseRadius * (0.6 + uLimbHeight[i]) * presence;',
    '    float cap = sdCapsule(p, vec3(0.0), dir*len, uBaseRadius*0.5, uBaseRadius*0.12);',
    '    d = smin(d, cap, uBaseRadius*0.4);',
    '  }',
    '  return d;',
    '}',
    'vec3 calcNormal(vec3 p) {',
    '  vec2 e = vec2(0.001, 0.0);',
    '  return normalize(vec3(',
    '    mapScene(p+e.xyy) - mapScene(p-e.xyy),',
    '    mapScene(p+e.yxy) - mapScene(p-e.yxy),',
    '    mapScene(p+e.yyx) - mapScene(p-e.yyx)',
    '  ));',
    '}',

    'void main() {',
    '  vec2 px = gl_FragCoord.xy - 0.5*uResolution;',
    '  mat3 camRot = rotY(uYaw) * rotX(uPitch);',
    '  vec3 ro = camRot * vec3(0.0, 0.0, -uCameraDist);',
    '  vec3 rd = camRot * normalize(vec3(px.x/uFocal, -px.y/uFocal, 1.0));',

    // Bounding-sphere early-out: skip the march entirely for rays that
    // cannot hit the object, which is most of the screen most of the time.
    '  float boundR = uBaseRadius * 2.8;',
    '  float b = dot(ro, rd);',
    '  float cDisc = b*b - (dot(ro,ro) - boundR*boundR);',
    '  if (cDisc < 0.0) { discard; }',

    '  float t = max(0.0, -b - sqrt(cDisc));',
    '  float tMax = -b + sqrt(cDisc);',
    '  bool hit = false;',
    '  vec3 p = ro;',
    '  for (int i = 0; i < 64; i++) {',
    '    p = ro + rd * t;',
    '    float d = mapScene(p);',
    '    if (d < 0.0015) { hit = true; break; }',
    '    t += d;',
    '    if (t > tMax) break;',
    '  }',
    '  if (!hit) { discard; }',

    '  vec3 n = calcNormal(p);',
    '  vec3 viewDir = normalize(ro - p);',
    '  float fresnel = mix(0.035, 1.0, pow(1.0 - clamp(dot(n, viewDir), 0.0, 1.0), 2.3));',

    // Reflection: a simple procedural sky, cool and pale at the top,
    // darker below, matching the system's own palette rather than a real
    // captured environment. Brighter than a literal render would be,
    // since this is standing in for reflections the scene doesn't have.
    '  vec3 reflDir = reflect(-viewDir, n);',
    '  vec3 sky = mix(vec3(0.05,0.06,0.08), vec3(0.78,0.84,0.9), smoothstep(-0.6, 0.8, reflDir.y));',

    // Refraction: bend the view ray through the surface and sample the
    // particle-flow pass rendered just before this one, so what shows
    // through the glass is the same flow, displaced.
    '  vec3 refrDir = refract(-viewDir, n, 1.0/1.45);',
    '  vec2 refrUv = gl_FragCoord.xy/uResolution + refrDir.xy * 0.11;',
    '  vec3 behind = texture2D(uSceneTex, clamp(refrUv, 0.0, 1.0)).rgb;',

    '  vec3 col = mix(behind, sky, fresnel);',
    '  col += vec3(0.025, 0.028, 0.033);', // a small ambient floor, so shadow side isn't pure black

    // Specular: the one fixed light, a hard glint. Same LIGHT the particle
    // pass and the rest of this system use.
    '  vec3 h = normalize(uLight + viewDir);',
    '  float spec = pow(max(dot(n, h), 0.0), 220.0);',
    '  col += vec3(spec) * 2.0;',

    '  float fogT = clamp((length(p - ro) - uCameraDist*0.5) / (uCameraDist*1.8), 0.0, 1.0);',
    '  col = mix(col, uBg, fogT * 0.12);',

    '  gl_FragColor = vec4(col, 1.0);',
    '}'
  ].join('\n');

  var quadProg = makeProgram(QUAD_VS, QUAD_FS);
  var quadBuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);

  // Particle points: physics stays in JS (unchanged), only the draw call
  // is new. Position is uploaded already rotated (camera space), so the
  // vertex shader only needs to project it, the same focal/(focal+z)
  // convention the Canvas 2D version used.
  var PART_VS = [
    'attribute vec3 aPos;',
    'attribute vec3 aColor;',
    'uniform float uFocal;',
    'uniform vec2 uResolution;',
    'varying vec3 vColor;',
    'void main() {',
    '  float camZ = max(aPos.z + uFocal, 1.0);',
    '  float scale = uFocal / camZ;',
    '  vec2 screenPx = vec2(aPos.x, -aPos.y) * scale;',
    '  gl_Position = vec4(screenPx / (uResolution * 0.5), 0.0, 1.0);',
    '  gl_PointSize = clamp(2.4 * scale, 1.0, 6.0);',
    '  vColor = aColor;',
    '}'
  ].join('\n');
  var PART_FS = [
    'precision mediump float;',
    'varying vec3 vColor;',
    'void main() {',
    '  vec2 d = gl_PointCoord - vec2(0.5);',
    '  float r = length(d);',
    '  if (r > 0.5) discard;',
    '  float a = smoothstep(0.5, 0.15, r);',
    '  gl_FragColor = vec4(vColor, a);',
    '}'
  ].join('\n');
  var partProg = makeProgram(PART_VS, PART_FS);
  var partBuf = gl.createBuffer();
  var partData = new Float32Array(N * 6); // x,y,z, r,g,b per particle

  // Backdrop: a licensed photo, not a procedural stand-in. Johnny Ho,
  // "Concrete hallway with dramatic light and shadow," Unsplash License
  // (free, no attribution required, unwatermarked) -- found and chosen
  // after the two reference photos sent in chat turned out to be
  // watermarked stock this session could never legally use or even read
  // as a file. Drawn before the particles in every pass, so the glass
  // pass sees it too when it samples this texture for refraction: the
  // photo's own diagonal light is what bends "through" the glass, not a
  // separate synthetic shaft on top of it. An earlier version of this
  // file drew that shaft procedurally, as an explicit substitute for a
  // photo the system didn't have yet; it's gone now that the real one is
  // here, so there's only one light doing the work instead of two.
  var BG_VS = 'attribute vec2 aPos;\nvoid main() { gl_Position = vec4(aPos, 0.0, 1.0); }';
  var BG_FS = [
    'precision highp float;',
    'uniform vec2 uResolution;',
    'uniform sampler2D uBgTex;',
    'uniform float uBgReady;',
    'uniform vec3 uBg;',
    'void main() {',
    '  vec2 uv = gl_FragCoord.xy / uResolution;',
    '  vec3 base = mix(uBg, texture2D(uBgTex, uv).rgb * 0.55, uBgReady);',
    '  gl_FragColor = vec4(base, 1.0);',
    '}'
  ].join('\n');
  var bgProg = makeProgram(BG_VS, BG_FS);
  var bgTex = gl.createTexture();
  var bgReady = 0;
  gl.bindTexture(gl.TEXTURE_2D, bgTex);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([10, 10, 10, 255]));
  var bgImg = new Image();
  bgImg.onload = function () {
    gl.bindTexture(gl.TEXTURE_2D, bgTex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true); // GL's v=0 is the bottom; images load top row first
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, bgImg);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    bgReady = 1;
  };
  bgImg.src = 'assets/concrete-hallway-light.jpg';

  function drawBackdrop() {
    gl.useProgram(bgProg);
    gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf);
    var aPos = gl.getAttribLocation(bgProg, 'aPos');
    gl.enableVertexAttribArray(aPos);
    gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);
    gl.uniform2f(gl.getUniformLocation(bgProg, 'uResolution'), canvas.width, canvas.height);
    gl.uniform3f(gl.getUniformLocation(bgProg, 'uBg'), BG[0], BG[1], BG[2]);
    gl.uniform1f(gl.getUniformLocation(bgProg, 'uBgReady'), bgReady);
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, bgTex);
    gl.uniform1i(gl.getUniformLocation(bgProg, 'uBgTex'), 1);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  }

  // Offscreen target the particle pass renders to, sampled by the glass
  // pass above for refraction.
  var sceneTex = gl.createTexture();
  var sceneFbo = gl.createFramebuffer();
  var texW = 0, texH = 0;
  function allocSceneTarget(w, h) {
    texW = w; texH = h;
    gl.bindTexture(gl.TEXTURE_2D, sceneTex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.bindFramebuffer(gl.FRAMEBUFFER, sceneFbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, sceneTex, 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }

  var ratio = 900 / 600;
  function resizeGL() {
    var cssWidth;
    if (fsElement()) {
      cssWidth = Math.min(window.innerWidth, window.innerHeight * ratio);
      canvas.style.width = cssWidth + 'px';
      canvas.style.height = (cssWidth / ratio) + 'px';
    } else {
      cssWidth = canvas.clientWidth || 900;
      canvas.style.width = '';
      canvas.style.height = '';
    }
    canvas.width = Math.round(cssWidth);
    canvas.height = Math.round(cssWidth / ratio);
    gl.viewport(0, 0, canvas.width, canvas.height);
    allocSceneTarget(canvas.width, canvas.height);
  }
  resizeGL();
  var resizeTimer = null;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(resizeGL, 120);
  });

  function drawParticles(toScreen) {
    gl.bindFramebuffer(gl.FRAMEBUFFER, toScreen ? null : sceneFbo);
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(BG[0], BG[1], BG[2], 1.0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    drawBackdrop();
    gl.useProgram(partProg);
    gl.bindBuffer(gl.ARRAY_BUFFER, partBuf);
    gl.bufferData(gl.ARRAY_BUFFER, partData, gl.DYNAMIC_DRAW);
    var aPos = gl.getAttribLocation(partProg, 'aPos');
    var aColor = gl.getAttribLocation(partProg, 'aColor');
    gl.enableVertexAttribArray(aPos);
    gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 24, 0);
    gl.enableVertexAttribArray(aColor);
    gl.vertexAttribPointer(aColor, 3, gl.FLOAT, false, 24, 12);
    gl.uniform1f(gl.getUniformLocation(partProg, 'uFocal'), canvas.width * 0.9);
    gl.uniform2f(gl.getUniformLocation(partProg, 'uResolution'), canvas.width, canvas.height);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.drawArrays(gl.POINTS, 0, N);
    gl.disable(gl.BLEND);
  }

  function draw() {
    CLOCK += 1 / 60;

    for (var i = 0; i < particles.length; i++) {
      var s = stepParticle(particles[i]);
      var v = rotateYP({ x: s.x, y: s.y, z: s.z }, yaw, pitch);
      var col = fog(speedColor(s.speed / MAX_SPEED), v.z);
      var o = i * 6;
      partData[o] = v.x; partData[o + 1] = v.y; partData[o + 2] = v.z;
      partData[o + 3] = col[0]; partData[o + 4] = col[1]; partData[o + 5] = col[2];
    }

    drawParticles(false); // to texture, for refraction
    drawParticles(true);  // to screen, as the visible backdrop

    gl.useProgram(quadProg);
    gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf);
    var aPos = gl.getAttribLocation(quadProg, 'aPos');
    gl.enableVertexAttribArray(aPos);
    gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);
    gl.uniform2f(gl.getUniformLocation(quadProg, 'uResolution'), canvas.width, canvas.height);
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uYaw'), yaw);
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uPitch'), pitch);
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uCameraDist'), 340);
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uFocal'), canvas.width * 0.9);
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uBaseRadius'), BASE_RADIUS);
    gl.uniform3fv(gl.getUniformLocation(quadProg, 'uLimbDir'), new Float32Array(limbDirs));
    gl.uniform1fv(gl.getUniformLocation(quadProg, 'uLimbHeight'), new Float32Array(limbHeights));
    gl.uniform1fv(gl.getUniformLocation(quadProg, 'uLimbPhase'), new Float32Array(limbPhases));
    gl.uniform1fv(gl.getUniformLocation(quadProg, 'uLimbSpeed'), new Float32Array(limbSpeeds));
    gl.uniform1f(gl.getUniformLocation(quadProg, 'uTime'), CLOCK);
    gl.uniform3f(gl.getUniformLocation(quadProg, 'uLight'), LIGHT.x, LIGHT.y, LIGHT.z);
    gl.uniform3f(gl.getUniformLocation(quadProg, 'uBg'), BG[0], BG[1], BG[2]);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, sceneTex);
    gl.uniform1i(gl.getUniformLocation(quadProg, 'uSceneTex'), 0);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);

    requestAnimationFrame(draw);
  }
  draw();

})();
