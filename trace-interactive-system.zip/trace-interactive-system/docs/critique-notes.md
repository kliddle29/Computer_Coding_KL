# Critique notes: v1 against the course's own lens

Self-assessment, written after the system was running. This file changed
more than once as the build changed; it describes the system as it
stands at the last commit, not its whole history. `decisions.md` has
that history.

## Clarity: can we tell what the system rules are by watching it run?

Mostly, though it takes longer to read than the earlier version did.
Deflection and speed-color are still visible right where they happen.
The fixed-axis flow still reads as a constant drift regardless of where
you drag the camera, and drag is still the only gesture. What's newly
hard to parse: a raymarched glass surface reads, correctly, as "this
object is glass," but doesn't by itself explain *why* it's glass, or
that the limbs growing and receding follow a fixed cycle rather than
random noise. A viewer has to trust the rules list and the reflection to
know that; the rendering alone doesn't make the rule legible the way the
flat-shaded version's color ramp did. That's a real cost of the more
sophisticated render, not a free upgrade.

## Restraint: does it avoid piling on effects and noise?

Less than the version before it, and it's worth saying so plainly
rather than arguing around it. This build now has: a raymarched glass
material with real reflection and refraction, a procedural sky, a
Fresnel term, a specular highlight, an animated light shaft, and nine
limbs cycling in and out on independent timers. Individually, each
addition is one rule, well-scoped and documented in `decisions.md`. Add
them together and the honest read is that this is a more maximal, more
technically impressive build than "functional, restrained, and
legible" asks for. It was built this way on direct, repeated request,
with the tradeoff stated at the time, not snuck in. Whether that's the
right call for what this module is grading is a real question, not a
settled one, and it's the first thing to revisit if critique feedback
says so. The one restraint that did hold: still one gesture, still no
toggle, still no second color source independent of speed or light.

## Intention: do the controls and behaviors feel chosen and coherent?

The live measurements are still real: temperature, speed, distance, now
also a light source that's genuinely computed, not painted on. The
biggest open gap: the raymarch material asks for a real environment to
reflect, and there isn't one, only a procedural gradient standing in for
sky. That's named directly in `decisions.md` rather than hidden, but it
means the "instrument panel, not a portrait" framing is under more
strain now than it was with flat shading. Flat shading never pretended
to show you something real behind its color; refraction, even
approximate refraction, invites a viewer to believe there's a real place
on the other side of the glass, and there isn't.

## Craft: does it run reliably, respond predictably, feel cared for?

Runs at a measured 60fps sustained, not just "seemed smooth," resizes
without breaking, and the wind readout still refuses to fabricate a
number if the fetch fails. New craft debt from the rewrite: this session
lost real time to a browser-caching bug that made several rounds of
verification silently stale (documented in `decisions.md`, in the
interest of an accurate record rather than a clean one), and the fix
was procedural (a cache-busting query during development) rather than
structural. `EXT_frag_depth` isn't used, so there's no real depth
compositing between the glass and the particles; the illusion holds
together because the Fresnel mix happens to fade toward reflection at
grazing angles, not because occlusion is actually computed, and that's
a simplification a more demanding scene would expose. Not yet verified
on a real touch device or a real GPU other than the one this session
had access to; WebGL support is broad but not universal, and this
version has no fallback for a browser without it beyond a plain text
notice.
