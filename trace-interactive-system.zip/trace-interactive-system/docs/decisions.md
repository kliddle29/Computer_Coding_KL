# Decisions: merging the four tests into v1

Working log of choices made while combining `trace-visual-rule-tests` into
one system. The Keep/Cut/Tighten/New-question inventory on the page covers
what the four *isolated* tests revealed. This file covers what changed
because they now have to run *together*.

## Structure

Started from a copy of `trace-visual-rule-tests` (`index.html`,
`style.css`, `script.js`, `assets/concrete-background.png`) rather than an
empty repo, per the build workflow. The projection, rotation, and lighting
helpers and the sigil generator (`makeSigil`, `rotateYP`, `project`,
`drawSigil`) carried over unchanged: Test 01 and Test 03 proved them
first.

## One canvas, not four

The four tests each isolated one rule on its own canvas so the rule alone
could be judged. v1 needs all four rules visible on the *same* field of
particles and the *same* solid, at once. That's the unknown this version
exists to test (see "new question" in the page's own reflection).

## Deflection generalized from 2D to 3D

Test 02 proved the deflection rule with a 2D simplification: six fixed
rows, each a fixed distance from the obstacle's center, with force
increasing row by row to make the rule's range visible for judging. That
row-based force gradient was a test fixture. Law 4 doesn't say the rule
gets stronger for some streamlines and weaker for others.

v1 replaces it with one uniform proximity rule in three dimensions. Each
particle's distance to the solid's center sets how hard it gets pushed
outward, perpendicular to the flow axis, eased toward that target instead
of snapping to it. The rule keeps Test 02's shape (proximity in, push
out, with a floor so a grazing approach still bends) and drops the
artificial per-lane gradient.

## Color reads off real per-particle speed

Test 04's particles were a single fixed color. The temperature-to-color
mapping lived in a separate "live conditions" bar that didn't drive
anything. Law 3 requires each streamline's color to come from its *own*
speed, which means something once speed varies per particle. It does now:
deflection changes how far each particle moves per frame as it passes the
solid. The five-stop ramp from the live-conditions test carries over
unchanged, fed by measured per-frame displacement instead of a slider
value.

## Wind strength is live now

Q07 named the fixed 108°F Phoenix reading as a placeholder for "the next
iteration." The live-conditions test already had a working fetch to
Open-Meteo for that exact location; it wasn't wired to anything. v1 keeps
the same fetch and coordinates and lets the result set the flow's base
speed instead of a decorative swatch. See the caption under the canvas on
the page itself for the exact source and request.

## Camera holds still; ambient auto-rotation is cut

Test 01 rotated on its own (ambient, to show the sigil from multiple
angles while idle). Test 03 held still until dragged, so "every bit of
motion on screen is caused by you." v1 keeps Test 03's version. Q06 says
touch controls perspective, and a camera that spins on its own makes it
harder to tell which motion is the gesture. The flow itself still moves
on its own; only the camera waits for input.

## Two gestures, cut back to one

Drag &rarr; yaw is the primary gesture and the only continuous one. v1
also kept click (or Enter/Space, from Test 01) as a second, discrete
gesture to regenerate the sigil at first. The brief's "Required
Components" section allows one or two primary inputs, and the two didn't
compete: different trigger, different parameter.

A stricter reading sat next to that one: "Combine, don't stack" asks for
*one* primary input, and this is graded work, so the ambiguity wasn't
worth leaving open. Cut click/Enter/Space-to-regenerate. Drag &rarr; yaw
is now the only input the system takes. The sigil still generates once,
at load (Law 1); the viewer can't regenerate it anymore. If a single
gesture ends up feeling thin rather than restrained, this is the one
thing to reconsider for v2.

## The readout never shows a guess as live

The first pass seeded the display with a plausible default (92°F) before
the fetch resolved. A failed fetch would keep showing that number with no
sign it wasn't real. Reworked it so the text stays `--` until the fetch
succeeds, and says `offline` if it fails. The simulation still runs on a
neutral default speed either way, but the readout never claims to be live
when it isn't. One limit worth naming: this is a single fetch on page
load, not a feed that keeps polling. It's accurate at the moment the page
opens, and it doesn't update again while a tab stays open.

## Fog toggle removed

Test 04's checkbox was already labeled a testing aid in its own caption.
v1 makes depth fog unconditional: "one atmosphere constraint that governs
the whole piece," with no toggle.

## Fullscreen is a viewing utility, not a second gesture language

The button in the corner of the stage requests fullscreen on the canvas.
It's not part of the system's gesture language and doesn't touch yaw,
the sigil, or the flow; it changes how big the stage renders, the same
role a video player's fullscreen button plays. Cutting to one gesture
earlier in this build was about inputs that control the system itself,
and this isn't one of those.

Browsers only grant fullscreen from a genuine, trusted user gesture, not
from a script-dispatched click, so this needs a real click from a real
person to test end to end. `fitCanvas()` sizes the canvas directly off
`window.innerWidth`/`innerHeight` while fullscreen is active, since a
fullscreen element's `clientWidth` isn't reliable across browsers before
the transition finishes.

## The sigil subdivides instead of adding a second shape

"More faces" could have meant swapping the icosahedron for a denser base
solid. It stays an icosahedron and instead runs one more step of the same
generating rule: split each face into four at its edge midpoints, twice,
turning 20 faces into 320. Law 1 asks for one generating rule, not one
specific polyhedron, so a second pass of the same rule fits inside it
rather than replacing it. A midpoint's distance from center is the
average of its two parents' distances, not snapped to a fixed radius, so
the jitter every vertex already carries blends across the added detail
instead of getting smoothed away by it.

Each face now gets a thin stroke along its edges. That's a rendering
choice, not a second shading rule: Law 5 still says brightness comes from
one light against the face normal, and the stroke only draws the
boundary that light already implies, so 320 faces read as facets instead
of blurring into a sphere.

## Streamlines trail instead of rendering as dots

The proposal's own reference image (Q07/REF) shows long streaks around
the solid, not discrete points. The canvas used to clear to solid
background every frame; it now clears to a low-alpha wash instead, so
each particle's last few positions stay faintly visible and read as a
trail. The sigil still redraws fully opaque on top every frame, so the
solid itself never ghosts, only the flow does.

## Wind noise is a wobble, not a rule

Added a small, smooth per-particle oscillation on top of the deflection
offset, so the flow reads as turbulent instead of laminar. It's seeded
per particle at spawn and driven by a frame counter, not `Math.random()`
every frame, so it stays smooth rather than static. It only changes
position, not the speed value that drives color, so Law 3 still reads
off one number: how fast the deflection rule is pushing a particle, nothing
else.

## Resistance retuned twice, both times by eye

First pass: `DEFLECT_STRENGTH` 70 to 100, `FLOOR_PUSH` 0.16 to 0.2,
`INFLUENCE_R` 115 to 130, so the bend around a heavier, more complex
solid read as strong enough to matter. Second pass, after "more drastic
movement, more resistance": `DEFLECT_STRENGTH` to 150, `FLOOR_PUSH` to
0.22, `INFLUENCE_R` to 140, `FLOW_UNIT` 1.35 to 2.1, and `EASE` 0.12 to
0.19 so particles react to the solid faster, not just further.
`SPEED_BOOST` and `MAX_SPEED` moved with them both times, by eye, to
keep the color ramp landing the same way: mostly cool, warm concentrated
at the solid. This is the same by-eye tuning the "v2" note already flags
for deriving from the sigil's geometry instead, now with two rounds of
drift behind it, which makes deriving it properly a better v2 candidate
than it already was.

## Protrusions are smooth limbs, applied after subdivision

First pass pushed out single coarse vertices before subdivision, which
read as angular spikes. The brief that came back asked for the opposite:
stay mostly spherical, with a few smooth limbs, like something growing
out of it rather than a faceted crystal. Reworked it to run after
subdivision instead: pick a handful of random directions on the sphere,
and for every vertex (all ~160 of them, not just the original 12), push
it outward by an amount that falls off smoothly with angular distance
from the nearest limb center. Vertices far from every limb center stay
at the plain jittered radius, so the base reads as round; vertices near
one taper up to it and back down, so the limb reads as a smooth bump,
not a hard point. Still one generating rule, still chosen once, at
generation, before anything is drawn; nothing moves after.

## A specular highlight, still one light

The glossier, icier look asked for a real highlight, not just a cooler
base color. Law 5 says brightness comes from the normal against one
fixed light, and a specular term is that same comparison, normal against
the same `LIGHT`, at a fixed view direction, just raised to a power so it
glints instead of shading gradually. No second light, no second color
source; the highlight goes through the same fog function as the rest of
the face. Whether a sharp specular glint reads as "Craft" or as spectacle
creeping back in is worth watching on the deployed page, in daylight and
in a dark room, not just in these screenshots.

## Three things this round asked to reconsider, resolved the same way

Three separate asks in this round, more toggles, the solid moving or
flowing over time, and a specific photo as the background, all came back
to the same instruction: follow the rules already written down. None of
the three got built as literally requested; here's what happened to each
one instead.

- **A shape that deforms over time.** Multiple requests asked for the
  solid itself to move or flow, not just the camera or the particles.
  Law 1 says geometry is fixed after generation. Kept Law 1. Complexity
  (limbs, jitter, subdivision) all happens once, at generation; nothing
  about the solid changes frame to frame. The camera and the flow field
  still move; the object it's flowing around doesn't.
- **More toggles.** Left as one gesture and no new controls. Restraint
  and the graded one-input decision stay as they were; fullscreen is
  still the only button on the stage, and it's a viewing option, not a
  system input.
- **A literal photo as the background.** Two reference images came in
  during this round; both were watermarked stock photos, and neither
  ever landed as a file this session could read from disk. Publishing a
  stock image without a license on a page going up under this author's
  name would be a real problem, license aside. Recreated the mood
  instead: a soft, cool radial gradient in the upper right of the page,
  built in CSS, layered over the same concrete asset the system already
  used. Nothing to license, because nothing was copied.

## Limb length overshot, then reverted

A follow-up asked to push limb length "way more longer." Raising
`LIMB_HEIGHT_MAX` that far, plus widening the angular radius, produced
four long arms and read as a starfish, not a sigil with a few smooth
additions to it. Direct feedback called it out immediately. Reverted
`LIMB_DOT_MIN`, `LIMB_HEIGHT_MIN`/`MAX`, `LIMB_SHARPNESS`, and
`SUBDIVISIONS` to the values from the commit before this round. The
paler, glossier shading stayed, and the facet stroke got softer still,
since a smoother reading of the surface asked for less visible faceting
between triangles, not more. Worth naming plainly: this was a real
overcorrection, not a small tuning miss, and it shipped before anyone
looked at it. The fix going forward is the same one already written down
for tuning constants generally, check by eye before moving on, just
applied with more discipline than it was here.

## The renderer became WebGL: a real raytracer, not a rendering trick

Requested directly, with the tradeoffs stated up front and accepted: real
glass needs light bouncing and bending, which a flat-shaded Canvas 2D
triangle can only ever approximate. That means a genuine technology
change, the first time anything in this build has moved off plain
Canvas 2D, though still no external library and no build step. Raw
WebGL and hand-written GLSL, not Three.js or any other engine, so the
"no framework" spirit survives even though "plain Canvas 2D" doesn't.

The solid is not raytraced as the literal triangle mesh from earlier
versions. Testing hundreds of triangles against every pixel's ray, every
frame, is the kind of cost that keeps that technique off real-time
budgets without a spatial acceleration structure this build doesn't
have. Instead the solid is a signed-distance field, a sphere with limb
capsules blended in by a smooth minimum, and the ray marches toward it
step by step. This is the standard technique for exactly this kind of
organic, blobby, real-time raytraced form (it's how most real-time
"raymarched" demos work); a bounding-sphere check skips the expensive
part of the march for the large majority of pixels that can't hit the
object at all. Measured at 60fps sustained over several seconds, not
estimated.

Two passes happen every frame: the particle flow renders first, to an
offscreen texture; the glass pass then raymarches the SDF and samples
that texture with the view ray bent through the surface (`refract`,
Snell's law, not a fake blur), mixed against a procedural reflection by
a Fresnel term (more reflective at grazing angles, more transparent
head-on, the real physical behavior, not a stylization of it). That's
what makes the flow visible *through* the glass, bent, rather than just
sitting behind it.

## What's real physics here and what's standing in for it

Worth being precise about, since "raytracing" can imply more than this
delivers. Real, computed per-pixel: the ray/SDF intersection, the
surface normal (from the SDF gradient, not stored per-vertex), Snell's-law
refraction, Fresnel-weighted reflection/transmission, and a Blinn-Phong
specular highlight from the system's one fixed light. Standing in for
something the scene doesn't have: the "sky" a reflection shows is a
procedural gradient, not a real captured or ray-traced environment,
because there isn't a real environment here to reflect. That's the
honest gap between this and the reference photo, restated once for the
record: real refraction and reflection, running on a made-up
environment, will read as convincingly glass-like without ever matching
a specific photograph pixel for pixel. No amount of tuning closes that
gap; only replacing the procedural sky with a real captured environment
map would, and there isn't one to use here.

## Law 5, revised: reflection and refraction, still one fixed light

The original Law 5 ("brightness comes from its normal against one fixed
light, that's the only shading rule") described flat Lambertian shading
with, later, a specular term added on top. A glass material needs more
than that: what a glass surface shows is mostly what's on the other side
of it, bent, and what's around it, reflected, not primarily its own lit
brightness. The light itself is still the same single fixed `LIGHT`
vector driving the specular glint, so "one light" survives; "that's the
only shading rule" does not, and pretending otherwise would misdescribe
what the shader actually does. The system panel on the page now says
what's true: the solid is glass, it reflects and refracts, over one
fixed light, rather than claiming an unmodified Law 5.

## Law 1, revised again: limb presence now cycles

A follow-up asked for more limbs that can disappear, specifically so the
mechanism reads as obvious rather than static. That is a second,
separate departure from Law 1's original text, on top of the SDF change
already logged above: which limbs are extended is no longer fixed after
generation, it changes over time. What's still true to Law 1's spirit,
kept on purpose rather than let go along with the rest: the change is
one rule, not arbitrary motion. A single clock drives every limb; each
limb's direction, length, phase offset, and cycle speed are still chosen
once, at generation, and never change after that. Only *presence*
animates, on a fixed trapezoidal cycle (out, held, retracting, held
absent, repeat), not a sine wave, so a limb reads as clearly there or
clearly not, not as a constant, hard-to-parse wobble. The page's rules
list says this directly now instead of the older, no-longer-true "fixed
once generated."

## The backdrop is the system's own asset, twice removed from the request

Three separate images came up this session, all watermarked stock
photos, none ever reachable as a file this session could read from
disk. What's actually running: `assets/concrete-background.png`, the
same file this system has used since the Visual Rule Tests, rendered as
a real WebGL texture behind the particle flow (not a CSS trick this
time), with a procedural diagonal light shaft over it built from the
same "cool light, upper right" mood as the earlier CSS version. That
shaft is genuinely visible through the glass via the refraction pass
above, which is what actually answers "a ray of light penetrating the
glass": not a separate volumetric-light system, just the same refraction
math already described, sampling a background that now has something
bright in it to bend.

## A debugging note worth keeping

A real bug hid behind a fake one this session: the browser cached
`index.html` and `script.js` aggressively enough that several rounds of
edits, reloads, and screenshots were verifying a stale build without any
error saying so. `console.log` calls from the page script weren't
reaching this session's log reader either, for the same reason DOM
reads worked throughout but a plain `window.__debug` global didn't: the
debugging tool runs in a separate JS world from the page. Once both were
identified, a cache-busting query string on the page request forced a
genuinely fresh load, and a DOM attribute (not a JS global, not
`console.log`) carried diagnostic values across the world boundary
reliably. Worth naming because it means every "confirmed working" claim
earlier in this file, from before this note, that was checked by
reloading and screenshotting rather than by checking file content
directly, should be treated as unverified until it's looked at again
under a real cache-busted load. Most of it was probably fine; the
specific tuning passes (fresnel range, ambient floor, shaft position)
were re-verified after this was found and are accurate as documented
above.

## The backdrop is now a real licensed photo, not a stand-in

The section above this one ends with "twice removed from the request."
It's no longer accurate, and rather than edit it to hide that this
changed, it stays as the record of what was true at the time and this
section replaces it going forward.

The two images sent in chat this session were both watermarked stock
photography. Watermarked stock isn't licensed for use, and neither was
ever reachable as a file this session could read from disk regardless,
so copying either one directly was never on the table. Asked directly
to find a similar image online instead, this session searched Unsplash
and Pexels for something in the same register (concrete, dramatic
directional light, monochrome) that carried a real license permitting
free use. A close visual match turned up first on Unsplash+, which is
paid and not actually free despite living on the same site as the free
tier; it was set aside for that reason, not used. The one actually
downloaded and wired in is Johnny Ho's "Concrete hallway with dramatic
light and shadow." Plain Unsplash License: free, no attribution legally
required, unwatermarked. Confirmed by opening the file and looking at
it before trusting it. It replaces `concrete-background.png` as the
active backdrop in both places that asset was used: the page's CSS
background and the WebGL texture sampled for refraction. The old file is
still in `assets/`, unused, not deleted, since deleting it wasn't asked
for and it cost nothing to leave it.

This also retired the procedural light shaft, in both the CSS version
and the GLSL version logged above. That shaft existed specifically
because the system didn't have a real photo with real dramatic light in
it yet; the comment above it said so directly. Keeping a synthetic
shaft on top of a photo that already has its own strong diagonal light
would mean two light directions fighting in the same frame. That's a
worse result than either one alone, not a richer one. The photo does
that work by itself now, sampled and slightly darkened so the particle
flow and glass still read clearly in front of it, same as before. What
refracts through the glass is that same texture, so a real photograph
bends through the surface now, not a procedural stand-in for one.

A first pass left the CSS background at full brightness, and a real
screenshot caught the problem the WebGL side never had: this photo has
a much brighter peak than the old concrete texture, and the "tighten"
row of the reflection panel landed almost directly on one of its light
triangles, unreadable at a glance. Fixed with a flat dark scrim under
the image in the CSS background stack, at 0.55 opacity. That number
isn't arbitrary: it's the same darkening factor already applied to this
photo in the WebGL shader, so both appearances of the same image are
toned the same way, not by two unrelated numbers.

One more thing worth naming honestly: `trace_master_reference.md`, the
document behind this whole project, states directly that the background
is procedural and not a photograph, and says why: two attempts to
generate a photographed version with Higgsfield failed for account
reasons, not code reasons, so a procedural texture shipped as the
working substitute. A real photo now sits in that spot instead. That is
a genuine departure from what the reference document specifies, on top
of Laws 1 and 5 above, not a loophole around it; asked directly, the
call was to keep the photo and record the departure here rather than
revert it. Everything else checked against that document, the five-stop
speed ramp's exact hex values, the #0A0A0A primary, the monospace-only
type rule, Law 2's fixed flow axis, Law 4's deflection, and Q08's rule
that a drag only ever moves the camera, held with no drift.
