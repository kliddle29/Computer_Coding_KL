# TRACE / Interactive System Build v1

One page, one system: a glass solid sits inside a constant flow of
streamline particles that deflect around it, color themselves by their
own speed, and bend visibly through the glass via real refraction. Drag
to orbit the camera. Built from the proven code in
`trace-visual-rule-tests`, merged into one coherent system per the
System Identity Proposal's laws, revised twice along the way; see
`docs/decisions.md` for exactly what changed and why.

Plain HTML + CSS + vanilla JS, still no framework and no build step, but
no longer plain Canvas 2D: the solid renders through raw WebGL and
hand-written GLSL (a raymarched signed-distance surface), added
mid-build on direct request. No Three.js, no other 3D library.

## Run locally

Serve the folder over HTTP so the background asset and the live weather
fetch both load:

```
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy

**Netlify (drag-and-drop):**
1. Go to [app.netlify.com/drop](https://app.netlify.com/drop).
2. Drag this whole folder onto the page.
3. Netlify gives you a live URL. That URL is what you submit.

**Netlify (via GitHub, recommended for staged commits):**
1. Push this repo to GitHub.
2. In Netlify, "Add new site" → "Import an existing project" → pick the repo.
3. No build command and no publish directory override needed: it's a
   static root.

## File structure

```
self-as-system-build-v1/
├─ index.html            reflection blocks + system panel + the canvas
├─ style.css              dark, restrained, monospace, same register as the proposal
├─ script.js               particle physics, gesture, and the WebGL/GLSL renderer
├─ docs/
│  ├─ decisions.md        integration decisions made while merging the four tests
│  └─ critique-notes.md   self-assessment against the course's critique lens
├─ process/
│  ├─ screenshots/        v1-01 through v1-04, one per build stage
│  └─ changelog.md        short log of what changed and why, as it happened
└─ assets/
   ├─ concrete-hallway-light.jpg   backdrop in use: licensed Unsplash photo, see docs/decisions.md
   └─ concrete-background.png      earlier backdrop asset, unused, kept rather than deleted
```

## What this version does

- **Sigil**: a sphere with limb capsules smooth-blended in, raymarched
  as a signed-distance field. Shape, direction, length, and per-limb
  timing are chosen once, at generation (Law 1); *which* limbs are
  currently extended follows a fixed time-driven cycle instead, a
  named, documented revision to Law 1's original "never edits a vertex
  after generation." See `docs/decisions.md`.
- **Material**: real glass shading, not a flat-shaded approximation.
  Fresnel-weighted reflection (a procedural sky, since there's no real
  environment here to reflect) mixed with Snell's-law refraction of the
  particle flow rendered just behind it, plus a Blinn-Phong specular
  highlight from the system's one fixed light. A revision to Law 5:
  still one light, no longer "that's the only shading rule."
- **Behavior**: streamlines flow along a fixed world axis (Law 2), carry
  a smooth per-particle wobble (wind noise, not a second rule), and
  deflect around the solid under a fixed proximity rule (Law 4). A
  particle's color is a live readout of its own current speed (Law 3),
  so the flow reads warmest where it bends.
- **Gesture**: drag orbits the camera on one axis, yaw only (Q06). It's
  the only input the system takes.
- **Atmosphere**: depth fog on the particle flow, and a real photo as
  the backdrop (Johnny Ho, "Concrete hallway with dramatic light and
  shadow," Unsplash License, free and unwatermarked) found as a
  licensed stand-in once it was clear the two reference photos sent
  during this build were watermarked stock this session could never
  legally use. That photo's own light is what visibly bends through
  the glass via the refraction pass above, not a synthetic effect
  layered on top of it.
- **Wind**: the flow's overall speed reads off a live temperature for
  Phoenix, AZ, fetched from the Open-Meteo API on each page load (see
  the caption under the canvas for the exact request). This is the
  "next iteration" the proposal's Q07 described, live as of this build.
  If the fetch fails, the readout says `offline` instead of showing a
  number that isn't real.
- **Fullscreen**: a button in the corner of the stage. A viewing option,
  not part of the gesture language; it changes how big the canvas
  renders and nothing about the system itself.

See `docs/decisions.md` for what changed in the merge and why.
